/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     QSTRING = 258,
     NUMBER = 259,
     GENERAL = 260,
     ADMIN = 261,
     LOCATION = 262,
     CONTACT = 263,
     CONNECT = 264,
     CLASS = 265,
     CHANNEL = 266,
     PINGFREQ = 267,
     CONNECTFREQ = 268,
     MAXLINKS = 269,
     MAXHOPS = 270,
     SENDQ = 271,
     NAME = 272,
     HOST = 273,
     IP = 274,
     USERNAME = 275,
     PASS = 276,
     LOCAL = 277,
     SECONDS = 278,
     MINUTES = 279,
     HOURS = 280,
     DAYS = 281,
     WEEKS = 282,
     MONTHS = 283,
     YEARS = 284,
     DECADES = 285,
     BYTES = 286,
     KBYTES = 287,
     MBYTES = 288,
     GBYTES = 289,
     TBYTES = 290,
     SERVER = 291,
     PORT = 292,
     MASK = 293,
     HUB = 294,
     LEAF = 295,
     UWORLD = 296,
     YES = 297,
     NO = 298,
     OPER = 299,
     VHOST = 300,
     HIDDEN = 301,
     MOTD = 302,
     JUPE = 303,
     NICK = 304,
     NUMERIC = 305,
     DESCRIPTION = 306,
     CLIENT = 307,
     KILL = 308,
     CRULE = 309,
     REAL = 310,
     REASON = 311,
     TFILE = 312,
     RULE = 313,
     ALL = 314,
     FEATURES = 315,
     QUARANTINE = 316,
     PSEUDO = 317,
     PREPEND = 318,
     USERMODE = 319,
     IAUTH = 320,
     TIMEOUT = 321,
     FAST = 322,
     AUTOCONNECT = 323,
     PROGRAM = 324,
     TOK_IPV4 = 325,
     TOK_IPV6 = 326,
     DNS = 327,
     FORWARDS = 328,
     SECURE = 329,
     WEBIRC = 330,
     SPOOF = 331,
     MAXCHANS = 332,
     REQUIRED = 333,
     SSL = 334,
     CERT = 335,
     CACERT = 336,
     TPRIV_CHAN_LIMIT = 337,
     TPRIV_MODE_LCHAN = 338,
     TPRIV_DEOP_LCHAN = 339,
     TPRIV_WALK_LCHAN = 340,
     TPRIV_LOCAL_KILL = 341,
     TPRIV_REHASH = 342,
     TPRIV_RESTART = 343,
     TPRIV_DIE = 344,
     TPRIV_GLINE = 345,
     TPRIV_LOCAL_GLINE = 346,
     TPRIV_LOCAL_JUPE = 347,
     TPRIV_LOCAL_BADCHAN = 348,
     TPRIV_LOCAL_OPMODE = 349,
     TPRIV_OPMODE = 350,
     TPRIV_SET = 351,
     TPRIV_WHOX = 352,
     TPRIV_BADCHAN = 353,
     TPRIV_SEE_CHAN = 354,
     TPRIV_SHOW_INVIS = 355,
     TPRIV_SHOW_ALL_INVIS = 356,
     TPRIV_PROPAGATE = 357,
     TPRIV_UNLIMIT_QUERY = 358,
     TPRIV_DISPLAY = 359,
     TPRIV_SEE_OPERS = 360,
     TPRIV_WIDE_GLINE = 361,
     TPRIV_FORCE_OPMODE = 362,
     TPRIV_FORCE_LOCAL_OPMODE = 363,
     TPRIV_APASS_OPMODE = 364,
     TPRIV_LIST_CHAN = 365,
     TPRIV_SEE_IDLETIME = 366,
     TPRIV_UMODE_NETSERV = 367,
     TPRIV_UMODE_NOCHAN = 368,
     TPRIV_UMODE_NOIDLE = 369,
     TPRIV_UMODE_CHSERV = 370,
     TPRIV_UMODE_XTRAOP = 371,
     TPRIV_FLOOD = 372,
     TPRIV_HALFFLOOD = 373,
     TPRIV_UNLIMITED_TARGET = 374,
     TPRIV_UMODE_OVERRIDECC = 375,
     TPRIV_HIDE_IDLETIME = 376,
     TPRIV_NOAMSG_OVERRIDE = 377
   };
#endif
/* Tokens.  */
#define QSTRING 258
#define NUMBER 259
#define GENERAL 260
#define ADMIN 261
#define LOCATION 262
#define CONTACT 263
#define CONNECT 264
#define CLASS 265
#define CHANNEL 266
#define PINGFREQ 267
#define CONNECTFREQ 268
#define MAXLINKS 269
#define MAXHOPS 270
#define SENDQ 271
#define NAME 272
#define HOST 273
#define IP 274
#define USERNAME 275
#define PASS 276
#define LOCAL 277
#define SECONDS 278
#define MINUTES 279
#define HOURS 280
#define DAYS 281
#define WEEKS 282
#define MONTHS 283
#define YEARS 284
#define DECADES 285
#define BYTES 286
#define KBYTES 287
#define MBYTES 288
#define GBYTES 289
#define TBYTES 290
#define SERVER 291
#define PORT 292
#define MASK 293
#define HUB 294
#define LEAF 295
#define UWORLD 296
#define YES 297
#define NO 298
#define OPER 299
#define VHOST 300
#define HIDDEN 301
#define MOTD 302
#define JUPE 303
#define NICK 304
#define NUMERIC 305
#define DESCRIPTION 306
#define CLIENT 307
#define KILL 308
#define CRULE 309
#define REAL 310
#define REASON 311
#define TFILE 312
#define RULE 313
#define ALL 314
#define FEATURES 315
#define QUARANTINE 316
#define PSEUDO 317
#define PREPEND 318
#define USERMODE 319
#define IAUTH 320
#define TIMEOUT 321
#define FAST 322
#define AUTOCONNECT 323
#define PROGRAM 324
#define TOK_IPV4 325
#define TOK_IPV6 326
#define DNS 327
#define FORWARDS 328
#define SECURE 329
#define WEBIRC 330
#define SPOOF 331
#define MAXCHANS 332
#define REQUIRED 333
#define SSL 334
#define CERT 335
#define CACERT 336
#define TPRIV_CHAN_LIMIT 337
#define TPRIV_MODE_LCHAN 338
#define TPRIV_DEOP_LCHAN 339
#define TPRIV_WALK_LCHAN 340
#define TPRIV_LOCAL_KILL 341
#define TPRIV_REHASH 342
#define TPRIV_RESTART 343
#define TPRIV_DIE 344
#define TPRIV_GLINE 345
#define TPRIV_LOCAL_GLINE 346
#define TPRIV_LOCAL_JUPE 347
#define TPRIV_LOCAL_BADCHAN 348
#define TPRIV_LOCAL_OPMODE 349
#define TPRIV_OPMODE 350
#define TPRIV_SET 351
#define TPRIV_WHOX 352
#define TPRIV_BADCHAN 353
#define TPRIV_SEE_CHAN 354
#define TPRIV_SHOW_INVIS 355
#define TPRIV_SHOW_ALL_INVIS 356
#define TPRIV_PROPAGATE 357
#define TPRIV_UNLIMIT_QUERY 358
#define TPRIV_DISPLAY 359
#define TPRIV_SEE_OPERS 360
#define TPRIV_WIDE_GLINE 361
#define TPRIV_FORCE_OPMODE 362
#define TPRIV_FORCE_LOCAL_OPMODE 363
#define TPRIV_APASS_OPMODE 364
#define TPRIV_LIST_CHAN 365
#define TPRIV_SEE_IDLETIME 366
#define TPRIV_UMODE_NETSERV 367
#define TPRIV_UMODE_NOCHAN 368
#define TPRIV_UMODE_NOIDLE 369
#define TPRIV_UMODE_CHSERV 370
#define TPRIV_UMODE_XTRAOP 371
#define TPRIV_FLOOD 372
#define TPRIV_HALFFLOOD 373
#define TPRIV_UNLIMITED_TARGET 374
#define TPRIV_UMODE_OVERRIDECC 375
#define TPRIV_HIDE_IDLETIME 376
#define TPRIV_NOAMSG_OVERRIDE 377




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 207 "./ircd_parser.y"
{
 char *text;
 int num;
}
/* Line 1489 of yacc.c.  */
#line 298 "y.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

