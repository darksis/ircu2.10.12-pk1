/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     QSTRING = 258,
     NUMBER = 259,
     GENERAL = 260,
     ADMIN = 261,
     LOCATION = 262,
     CONTACT = 263,
     CONNECT = 264,
     CLASS = 265,
     CHANNEL = 266,
     PINGFREQ = 267,
     CONNECTFREQ = 268,
     MAXLINKS = 269,
     MAXHOPS = 270,
     SENDQ = 271,
     NAME = 272,
     HOST = 273,
     IP = 274,
     USERNAME = 275,
     PASS = 276,
     LOCAL = 277,
     SECONDS = 278,
     MINUTES = 279,
     HOURS = 280,
     DAYS = 281,
     WEEKS = 282,
     MONTHS = 283,
     YEARS = 284,
     DECADES = 285,
     BYTES = 286,
     KBYTES = 287,
     MBYTES = 288,
     GBYTES = 289,
     TBYTES = 290,
     SERVER = 291,
     PORT = 292,
     MASK = 293,
     HUB = 294,
     LEAF = 295,
     UWORLD = 296,
     YES = 297,
     NO = 298,
     OPER = 299,
     VHOST = 300,
     HIDDEN = 301,
     MOTD = 302,
     JUPE = 303,
     NICK = 304,
     NUMERIC = 305,
     DESCRIPTION = 306,
     CLIENT = 307,
     KILL = 308,
     CRULE = 309,
     REAL = 310,
     REASON = 311,
     TFILE = 312,
     RULE = 313,
     ALL = 314,
     FEATURES = 315,
     QUARANTINE = 316,
     PSEUDO = 317,
     PREPEND = 318,
     USERMODE = 319,
     IAUTH = 320,
     TIMEOUT = 321,
     FAST = 322,
     AUTOCONNECT = 323,
     PROGRAM = 324,
     TOK_IPV4 = 325,
     TOK_IPV6 = 326,
     DNS = 327,
     FORWARDS = 328,
     SECURE = 329,
     WEBIRC = 330,
     SPOOF = 331,
     MAXCHANS = 332,
     REQUIRED = 333,
     SSL = 334,
     CERT = 335,
     CACERT = 336,
     TPRIV_CHAN_LIMIT = 337,
     TPRIV_MODE_LCHAN = 338,
     TPRIV_DEOP_LCHAN = 339,
     TPRIV_WALK_LCHAN = 340,
     TPRIV_LOCAL_KILL = 341,
     TPRIV_REHASH = 342,
     TPRIV_RESTART = 343,
     TPRIV_DIE = 344,
     TPRIV_GLINE = 345,
     TPRIV_LOCAL_GLINE = 346,
     TPRIV_LOCAL_JUPE = 347,
     TPRIV_LOCAL_BADCHAN = 348,
     TPRIV_LOCAL_OPMODE = 349,
     TPRIV_OPMODE = 350,
     TPRIV_SET = 351,
     TPRIV_WHOX = 352,
     TPRIV_BADCHAN = 353,
     TPRIV_SEE_CHAN = 354,
     TPRIV_SHOW_INVIS = 355,
     TPRIV_SHOW_ALL_INVIS = 356,
     TPRIV_PROPAGATE = 357,
     TPRIV_UNLIMIT_QUERY = 358,
     TPRIV_DISPLAY = 359,
     TPRIV_SEE_OPERS = 360,
     TPRIV_WIDE_GLINE = 361,
     TPRIV_FORCE_OPMODE = 362,
     TPRIV_FORCE_LOCAL_OPMODE = 363,
     TPRIV_APASS_OPMODE = 364,
     TPRIV_LIST_CHAN = 365,
     TPRIV_SEE_IDLETIME = 366,
     TPRIV_UMODE_NETSERV = 367,
     TPRIV_UMODE_NOCHAN = 368,
     TPRIV_UMODE_NOIDLE = 369,
     TPRIV_UMODE_CHSERV = 370,
     TPRIV_UMODE_XTRAOP = 371,
     TPRIV_FLOOD = 372,
     TPRIV_HALFFLOOD = 373,
     TPRIV_UNLIMITED_TARGET = 374,
     TPRIV_UMODE_OVERRIDECC = 375,
     TPRIV_HIDE_IDLETIME = 376,
     TPRIV_NOAMSG_OVERRIDE = 377
   };
#endif
/* Tokens.  */
#define QSTRING 258
#define NUMBER 259
#define GENERAL 260
#define ADMIN 261
#define LOCATION 262
#define CONTACT 263
#define CONNECT 264
#define CLASS 265
#define CHANNEL 266
#define PINGFREQ 267
#define CONNECTFREQ 268
#define MAXLINKS 269
#define MAXHOPS 270
#define SENDQ 271
#define NAME 272
#define HOST 273
#define IP 274
#define USERNAME 275
#define PASS 276
#define LOCAL 277
#define SECONDS 278
#define MINUTES 279
#define HOURS 280
#define DAYS 281
#define WEEKS 282
#define MONTHS 283
#define YEARS 284
#define DECADES 285
#define BYTES 286
#define KBYTES 287
#define MBYTES 288
#define GBYTES 289
#define TBYTES 290
#define SERVER 291
#define PORT 292
#define MASK 293
#define HUB 294
#define LEAF 295
#define UWORLD 296
#define YES 297
#define NO 298
#define OPER 299
#define VHOST 300
#define HIDDEN 301
#define MOTD 302
#define JUPE 303
#define NICK 304
#define NUMERIC 305
#define DESCRIPTION 306
#define CLIENT 307
#define KILL 308
#define CRULE 309
#define REAL 310
#define REASON 311
#define TFILE 312
#define RULE 313
#define ALL 314
#define FEATURES 315
#define QUARANTINE 316
#define PSEUDO 317
#define PREPEND 318
#define USERMODE 319
#define IAUTH 320
#define TIMEOUT 321
#define FAST 322
#define AUTOCONNECT 323
#define PROGRAM 324
#define TOK_IPV4 325
#define TOK_IPV6 326
#define DNS 327
#define FORWARDS 328
#define SECURE 329
#define WEBIRC 330
#define SPOOF 331
#define MAXCHANS 332
#define REQUIRED 333
#define SSL 334
#define CERT 335
#define CACERT 336
#define TPRIV_CHAN_LIMIT 337
#define TPRIV_MODE_LCHAN 338
#define TPRIV_DEOP_LCHAN 339
#define TPRIV_WALK_LCHAN 340
#define TPRIV_LOCAL_KILL 341
#define TPRIV_REHASH 342
#define TPRIV_RESTART 343
#define TPRIV_DIE 344
#define TPRIV_GLINE 345
#define TPRIV_LOCAL_GLINE 346
#define TPRIV_LOCAL_JUPE 347
#define TPRIV_LOCAL_BADCHAN 348
#define TPRIV_LOCAL_OPMODE 349
#define TPRIV_OPMODE 350
#define TPRIV_SET 351
#define TPRIV_WHOX 352
#define TPRIV_BADCHAN 353
#define TPRIV_SEE_CHAN 354
#define TPRIV_SHOW_INVIS 355
#define TPRIV_SHOW_ALL_INVIS 356
#define TPRIV_PROPAGATE 357
#define TPRIV_UNLIMIT_QUERY 358
#define TPRIV_DISPLAY 359
#define TPRIV_SEE_OPERS 360
#define TPRIV_WIDE_GLINE 361
#define TPRIV_FORCE_OPMODE 362
#define TPRIV_FORCE_LOCAL_OPMODE 363
#define TPRIV_APASS_OPMODE 364
#define TPRIV_LIST_CHAN 365
#define TPRIV_SEE_IDLETIME 366
#define TPRIV_UMODE_NETSERV 367
#define TPRIV_UMODE_NOCHAN 368
#define TPRIV_UMODE_NOIDLE 369
#define TPRIV_UMODE_CHSERV 370
#define TPRIV_UMODE_XTRAOP 371
#define TPRIV_FLOOD 372
#define TPRIV_HALFFLOOD 373
#define TPRIV_UNLIMITED_TARGET 374
#define TPRIV_UMODE_OVERRIDECC 375
#define TPRIV_HIDE_IDLETIME 376
#define TPRIV_NOAMSG_OVERRIDE 377




/* Copy the first part of user declarations.  */
#line 22 "./ircd_parser.y"


#include "config.h"
#include "s_conf.h"
#include "class.h"
#include "client.h"
#include "crule.h"
#include "ircd_features.h"
#include "fileio.h"
#include "gline.h"
#include "hash.h"
#include "ircd.h"
#include "ircd_alloc.h"
#include "ircd_chattr.h"
#include "ircd_log.h"
#include "ircd_reply.h"
#include "ircd_snprintf.h"
#include "ircd_string.h"
#include "list.h"
#include "listener.h"
#include "match.h"
#include "motd.h"
#include "numeric.h"
#include "numnicks.h"
#include "opercmds.h"
#include "parse.h"
#include "res.h"
#include "s_auth.h"
#include "s_bsd.h"
#include "s_conf.h"
#include "s_debug.h"
#include "s_misc.h"
#include "send.h"
#include "struct.h"
#include "sys.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>

#define MAX_STRINGS 80 /* Maximum number of feature params. */
#define USE_IPV4 (1 << 16)
#define USE_IPV6 (1 << 17)

  extern struct LocalConf   localConf;
  extern struct DenyConf*   denyConfList;
  extern struct CRuleConf*  cruleConfList;
  extern struct ServerConf* serverConfList;
  extern struct s_map*      GlobalServiceMapList;
  extern struct qline*      GlobalQuarantineList;

  int yylex(void);
  /* Now all the globals we need :/... */
  int tping, tconn, maxlinks, sendq, port, invert, stringno, flags, maxchans, iauth_required = 0;
  char *name, *pass, *host, *ip, *username, *origin, *hub_limit;
  struct SLink *hosts;
  char *stringlist[MAX_STRINGS];
  struct ListenerFlags listen_flags;
  struct ConnectionClass *c_class;
  struct DenyConf *dconf;
  struct ServerConf *sconf;
  struct s_map *smap;
  struct Privs privs;
  struct Privs privs_dirty;
  struct webirc_block *webirc;

static void parse_error(char *pattern,...) {
  static char error_buffer[1024];
  va_list vl;
  va_start(vl,pattern);
  ircd_vsnprintf(NULL, error_buffer, sizeof(error_buffer), pattern, vl);
  va_end(vl);
  yyerror(error_buffer);
}

static void free_slist(struct SLink **link) {
  struct SLink *next;
  while (*link != NULL) {
    next = (*link)->next;
    MyFree((*link)->value.cp);
    free_link(*link);
    *link = next;
  }
}



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 207 "./ircd_parser.y"
{
 char *text;
 int num;
}
/* Line 187 of yacc.c.  */
#line 432 "y.tab.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 445 "y.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  62
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   686

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  134
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  155
/* YYNRULES -- Number of rules.  */
#define YYNRULES  325
/* YYNRULES -- Number of states.  */
#define YYNSTATES  637

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   377

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   133,     2,     2,     2,     2,     2,     2,
     128,   129,   125,   123,     2,   124,     2,   126,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,   127,
       2,   132,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   130,     2,   131,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,     8,    10,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    30,    32,    34,    36,    38,
      40,    42,    44,    46,    49,    51,    53,    56,    58,    61,
      63,    65,    67,    69,    71,    73,    75,    77,    79,    82,
      85,    88,    91,    94,    96,   100,   104,   108,   112,   116,
     122,   125,   127,   129,   134,   135,   142,   145,   147,   149,
     151,   153,   155,   157,   159,   164,   169,   174,   179,   186,
     192,   193,   200,   203,   205,   207,   209,   214,   219,   220,
     227,   230,   232,   234,   236,   238,   240,   242,   244,   246,
     248,   253,   258,   263,   268,   273,   278,   283,   284,   291,
     294,   296,   298,   300,   302,   304,   306,   308,   310,   312,
     314,   316,   318,   320,   325,   330,   335,   340,   345,   350,
     353,   356,   361,   366,   371,   376,   381,   386,   392,   395,
     397,   399,   404,   410,   412,   415,   417,   419,   421,   423,
     425,   430,   435,   440,   445,   450,   452,   454,   456,   458,
     460,   462,   464,   466,   468,   470,   472,   474,   476,   478,
     480,   482,   484,   486,   488,   490,   492,   494,   496,   498,
     500,   502,   504,   506,   508,   510,   512,   514,   516,   518,
     520,   522,   524,   526,   528,   530,   532,   534,   536,   538,
     540,   542,   543,   545,   547,   550,   553,   559,   562,   564,
     566,   568,   570,   572,   574,   576,   578,   584,   590,   597,
     602,   607,   612,   617,   622,   627,   632,   633,   640,   643,
     645,   647,   649,   651,   653,   655,   657,   659,   664,   669,
     674,   679,   684,   689,   694,   695,   702,   705,   707,   709,
     711,   713,   715,   717,   722,   727,   732,   737,   742,   743,
     750,   753,   755,   757,   759,   761,   766,   771,   776,   781,
     787,   790,   792,   794,   796,   801,   806,   812,   815,   817,
     818,   824,   827,   829,   831,   837,   840,   842,   847,   848,
     856,   859,   861,   863,   865,   867,   869,   874,   879,   884,
     887,   893,   896,   898,   900,   902,   903,   909,   914,   915,
     922,   925,   927,   932,   933,   940,   943,   945,   947,   949,
     951,   953,   955,   957,   962,   967,   973,   978,   984,   989,
     995,   998,  1000,  1002,  1004,  1009
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     135,     0,    -1,   135,   136,    -1,   136,    -1,   157,    -1,
     147,    -1,   163,    -1,   174,    -1,   190,    -1,   194,    -1,
     205,    -1,   143,    -1,   215,    -1,   226,    -1,   235,    -1,
     242,    -1,   247,    -1,   253,    -1,   256,    -1,   264,    -1,
     270,    -1,   274,    -1,   284,    -1,     1,   127,    -1,   142,
      -1,   138,    -1,   138,   139,    -1,   139,    -1,   142,   140,
      -1,    23,    -1,    24,    -1,    25,    -1,    26,    -1,    27,
      -1,    28,    -1,    29,    -1,    30,    -1,   142,    -1,   142,
      31,    -1,   142,    32,    -1,   142,    33,    -1,   142,    34,
      -1,   142,    35,    -1,     4,    -1,   142,   123,   142,    -1,
     142,   124,   142,    -1,   142,   125,   142,    -1,   142,   126,
     142,    -1,   128,   142,   129,    -1,    48,   130,   144,   131,
     127,    -1,   145,   144,    -1,   145,    -1,   146,    -1,    49,
     132,     3,   127,    -1,    -1,     5,   148,   130,   149,   131,
     127,    -1,   150,   149,    -1,   150,    -1,   151,    -1,   152,
      -1,   154,    -1,   153,    -1,   155,    -1,   156,    -1,    50,
     132,     4,   127,    -1,    17,   132,     3,   127,    -1,    51,
     132,     3,   127,    -1,    45,   132,     3,   127,    -1,    72,
      45,   132,   204,     3,   127,    -1,    72,    36,   132,     3,
     127,    -1,    -1,     6,   158,   130,   159,   131,   127,    -1,
     159,   160,    -1,   160,    -1,   161,    -1,   162,    -1,     7,
     132,     3,   127,    -1,     8,   132,     3,   127,    -1,    -1,
      10,   164,   130,   165,   131,   127,    -1,   166,   165,    -1,
     166,    -1,   167,    -1,   169,    -1,   170,    -1,   171,    -1,
     172,    -1,   173,    -1,   201,    -1,   168,    -1,    17,   132,
       3,   127,    -1,    77,   132,   142,   127,    -1,    12,   132,
     137,   127,    -1,    13,   132,   137,   127,    -1,    14,   132,
     142,   127,    -1,    16,   132,   141,   127,    -1,    64,   132,
       3,   127,    -1,    -1,     9,   175,   130,   176,   131,   127,
      -1,   177,   176,    -1,   177,    -1,   178,    -1,   179,    -1,
     180,    -1,   181,    -1,   182,    -1,   183,    -1,   184,    -1,
     185,    -1,   186,    -1,   187,    -1,   188,    -1,   189,    -1,
      17,   132,     3,   127,    -1,    21,   132,     3,   127,    -1,
      10,   132,     3,   127,    -1,    18,   132,     3,   127,    -1,
      37,   132,     4,   127,    -1,    45,   132,     3,   127,    -1,
      40,   127,    -1,    39,   127,    -1,    39,   132,     3,   127,
      -1,    15,   132,   142,   127,    -1,    68,   132,    42,   127,
      -1,    68,   132,    43,   127,    -1,    74,   132,    42,   127,
      -1,    74,   132,    43,   127,    -1,    41,   130,   191,   131,
     127,    -1,   192,   191,    -1,   192,    -1,   193,    -1,    17,
     132,     3,   127,    -1,    44,   130,   195,   131,   127,    -1,
     196,    -1,   195,   196,    -1,   197,    -1,   198,    -1,   199,
      -1,   200,    -1,   201,    -1,    17,   132,     3,   127,    -1,
      21,   132,     3,   127,    -1,    18,   132,     3,   127,    -1,
      10,   132,     3,   127,    -1,   202,   132,   203,   127,    -1,
      82,    -1,    83,    -1,    84,    -1,    85,    -1,   111,    -1,
     121,    -1,   113,    -1,   114,    -1,   115,    -1,   116,    -1,
     112,    -1,   117,    -1,   118,    -1,   119,    -1,   120,    -1,
      53,    -1,    86,    -1,    87,    -1,    88,    -1,    89,    -1,
      90,    -1,    91,    -1,    48,    -1,    92,    -1,    94,    -1,
      95,    -1,    96,    -1,    97,    -1,    98,    -1,    93,    -1,
      99,    -1,   100,    -1,   101,    -1,   102,    -1,   103,    -1,
     104,    -1,   105,    -1,   106,    -1,   110,    -1,    22,    -1,
     107,    -1,   108,    -1,   122,    -1,   109,    -1,    42,    -1,
      43,    -1,    -1,    70,    -1,    71,    -1,    70,    71,    -1,
      71,    70,    -1,    37,   130,   206,   131,   127,    -1,   207,
     206,    -1,   207,    -1,   208,    -1,   209,    -1,   210,    -1,
     211,    -1,   212,    -1,   213,    -1,   214,    -1,    37,   132,
     204,     4,   127,    -1,    45,   132,   204,     3,   127,    -1,
      45,   132,   204,     3,     4,   127,    -1,    38,   132,     3,
     127,    -1,    36,   132,    42,   127,    -1,    36,   132,    43,
     127,    -1,    46,   132,    42,   127,    -1,    46,   132,    43,
     127,    -1,    74,   132,    42,   127,    -1,    74,   132,    43,
     127,    -1,    -1,    52,   216,   130,   217,   131,   127,    -1,
     218,   217,    -1,   218,    -1,   219,    -1,   220,    -1,   221,
      -1,   222,    -1,   223,    -1,   224,    -1,   225,    -1,    18,
     132,     3,   127,    -1,    19,   132,     3,   127,    -1,    20,
     132,     3,   127,    -1,    10,   132,     3,   127,    -1,    21,
     132,     3,   127,    -1,    14,   132,   142,   127,    -1,    37,
     132,   142,   127,    -1,    -1,    53,   227,   130,   228,   131,
     127,    -1,   229,   228,    -1,   229,    -1,   230,    -1,   232,
      -1,   231,    -1,   234,    -1,   233,    -1,    18,   132,     3,
     127,    -1,    20,   132,     3,   127,    -1,    55,   132,     3,
     127,    -1,    56,   132,     3,   127,    -1,    57,   132,     3,
     127,    -1,    -1,    54,   236,   130,   237,   131,   127,    -1,
     238,   237,    -1,   238,    -1,   239,    -1,   240,    -1,   241,
      -1,    36,   132,     3,   127,    -1,    58,   132,     3,   127,
      -1,    59,   132,    42,   127,    -1,    59,   132,    43,   127,
      -1,    47,   130,   243,   131,   127,    -1,   244,   243,    -1,
     244,    -1,   245,    -1,   246,    -1,    18,   132,     3,   127,
      -1,    57,   132,     3,   127,    -1,    60,   130,   248,   131,
     127,    -1,   248,   249,    -1,   249,    -1,    -1,     3,   250,
     132,   251,   127,    -1,   251,   252,    -1,   252,    -1,     3,
      -1,    61,   130,   254,   131,   127,    -1,   254,   255,    -1,
     255,    -1,     3,   132,     3,   127,    -1,    -1,    62,     3,
     130,   257,   258,   131,   127,    -1,   259,   258,    -1,   259,
      -1,   260,    -1,   261,    -1,   262,    -1,   263,    -1,    17,
     132,     3,   127,    -1,    63,   132,     3,   127,    -1,    49,
     132,     3,   127,    -1,    67,   127,    -1,    65,   130,   265,
     131,   127,    -1,   266,   265,    -1,   266,    -1,   267,    -1,
     269,    -1,    -1,    69,   132,   268,   251,   127,    -1,    78,
     132,   203,   127,    -1,    -1,    73,   271,   130,   272,   131,
     127,    -1,   272,   273,    -1,   273,    -1,     3,   132,     3,
     127,    -1,    -1,    75,   275,   130,   276,   131,   127,    -1,
     276,   277,    -1,   277,    -1,   278,    -1,   279,    -1,   280,
      -1,   281,    -1,   282,    -1,   283,    -1,    21,   132,     3,
     127,    -1,    18,   132,     3,   127,    -1,    18,   133,   132,
       3,   127,    -1,    76,   132,     3,   127,    -1,    76,   133,
     132,     3,   127,    -1,    17,   132,     3,   127,    -1,    79,
     130,   285,   131,   127,    -1,   285,   286,    -1,   286,    -1,
     287,    -1,   288,    -1,    80,   132,     3,   127,    -1,    81,
     132,     3,   127,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   214,   214,   214,   215,   215,   215,   215,   216,   216,
     216,   216,   216,   217,   217,   217,   217,   217,   218,   218,
     218,   218,   218,   218,   222,   222,   224,   227,   229,   234,
     235,   236,   237,   238,   239,   240,   241,   244,   247,   250,
     253,   256,   259,   265,   269,   272,   275,   278,   285,   290,
     291,   291,   292,   293,   300,   299,   310,   310,   311,   311,
     311,   311,   312,   312,   314,   323,   335,   342,   359,   381,
     390,   389,   405,   405,   406,   406,   407,   416,   422,   422,
     448,   448,   449,   449,   449,   449,   450,   450,   450,   450,
     451,   456,   460,   464,   468,   472,   476,   483,   482,   527,
     527,   528,   528,   528,   528,   529,   529,   529,   529,   530,
     530,   530,   530,   531,   536,   541,   548,   553,   557,   562,
     566,   571,   576,   580,   581,   582,   583,   585,   586,   586,
     587,   588,   593,   627,   627,   628,   628,   628,   628,   628,
     629,   634,   639,   655,   663,   673,   674,   675,   676,   677,
     678,   679,   680,   681,   682,   683,   684,   685,   686,   687,
     688,   689,   690,   691,   692,   693,   694,   695,   696,   697,
     698,   699,   700,   701,   702,   703,   704,   705,   706,   707,
     708,   709,   710,   711,   712,   713,   714,   715,   716,   718,
     718,   724,   725,   726,   727,   728,   732,   767,   767,   768,
     768,   768,   768,   768,   768,   768,   769,   780,   790,   804,
     810,   813,   818,   821,   826,   829,   835,   834,   880,   880,
     881,   881,   881,   881,   881,   881,   881,   882,   895,   909,
     914,   921,   926,   930,   936,   935,   955,   955,   956,   956,
     956,   956,   956,   957,   976,   982,   988,   995,  1003,  1002,
    1035,  1035,  1036,  1036,  1036,  1038,  1047,  1053,  1056,  1061,
    1072,  1072,  1073,  1073,  1074,  1083,  1089,  1090,  1090,  1093,
    1092,  1103,  1103,  1104,  1112,  1113,  1113,  1114,  1124,  1123,
    1152,  1152,  1153,  1153,  1153,  1153,  1154,  1159,  1164,  1178,
    1183,  1194,  1194,  1195,  1195,  1197,  1196,  1205,  1210,  1210,
    1216,  1216,  1217,  1225,  1225,  1241,  1241,  1242,  1242,  1242,
    1242,  1242,  1242,  1243,  1249,  1255,  1261,  1267,  1273,  1292,
    1293,  1293,  1294,  1294,  1295,  1299
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "QSTRING", "NUMBER", "GENERAL", "ADMIN",
  "LOCATION", "CONTACT", "CONNECT", "CLASS", "CHANNEL", "PINGFREQ",
  "CONNECTFREQ", "MAXLINKS", "MAXHOPS", "SENDQ", "NAME", "HOST", "IP",
  "USERNAME", "PASS", "LOCAL", "SECONDS", "MINUTES", "HOURS", "DAYS",
  "WEEKS", "MONTHS", "YEARS", "DECADES", "BYTES", "KBYTES", "MBYTES",
  "GBYTES", "TBYTES", "SERVER", "PORT", "MASK", "HUB", "LEAF", "UWORLD",
  "YES", "NO", "OPER", "VHOST", "HIDDEN", "MOTD", "JUPE", "NICK",
  "NUMERIC", "DESCRIPTION", "CLIENT", "KILL", "CRULE", "REAL", "REASON",
  "TFILE", "RULE", "ALL", "FEATURES", "QUARANTINE", "PSEUDO", "PREPEND",
  "USERMODE", "IAUTH", "TIMEOUT", "FAST", "AUTOCONNECT", "PROGRAM",
  "TOK_IPV4", "TOK_IPV6", "DNS", "FORWARDS", "SECURE", "WEBIRC", "SPOOF",
  "MAXCHANS", "REQUIRED", "SSL", "CERT", "CACERT", "TPRIV_CHAN_LIMIT",
  "TPRIV_MODE_LCHAN", "TPRIV_DEOP_LCHAN", "TPRIV_WALK_LCHAN",
  "TPRIV_LOCAL_KILL", "TPRIV_REHASH", "TPRIV_RESTART", "TPRIV_DIE",
  "TPRIV_GLINE", "TPRIV_LOCAL_GLINE", "TPRIV_LOCAL_JUPE",
  "TPRIV_LOCAL_BADCHAN", "TPRIV_LOCAL_OPMODE", "TPRIV_OPMODE", "TPRIV_SET",
  "TPRIV_WHOX", "TPRIV_BADCHAN", "TPRIV_SEE_CHAN", "TPRIV_SHOW_INVIS",
  "TPRIV_SHOW_ALL_INVIS", "TPRIV_PROPAGATE", "TPRIV_UNLIMIT_QUERY",
  "TPRIV_DISPLAY", "TPRIV_SEE_OPERS", "TPRIV_WIDE_GLINE",
  "TPRIV_FORCE_OPMODE", "TPRIV_FORCE_LOCAL_OPMODE", "TPRIV_APASS_OPMODE",
  "TPRIV_LIST_CHAN", "TPRIV_SEE_IDLETIME", "TPRIV_UMODE_NETSERV",
  "TPRIV_UMODE_NOCHAN", "TPRIV_UMODE_NOIDLE", "TPRIV_UMODE_CHSERV",
  "TPRIV_UMODE_XTRAOP", "TPRIV_FLOOD", "TPRIV_HALFFLOOD",
  "TPRIV_UNLIMITED_TARGET", "TPRIV_UMODE_OVERRIDECC",
  "TPRIV_HIDE_IDLETIME", "TPRIV_NOAMSG_OVERRIDE", "'+'", "'-'", "'*'",
  "'/'", "';'", "'('", "')'", "'{'", "'}'", "'='", "'!'", "$accept",
  "blocks", "block", "timespec", "factoredtimes", "factoredtime",
  "timefactor", "sizespec", "expr", "jupeblock", "jupeitems", "jupeitem",
  "jupenick", "generalblock", "@1", "generalitems", "generalitem",
  "generalnumeric", "generalname", "generaldesc", "generalvhost",
  "generaldnsvhost", "generaldnsserver", "adminblock", "@2", "adminitems",
  "adminitem", "adminlocation", "admincontact", "classblock", "@3",
  "classitems", "classitem", "classname", "maxchans", "classpingfreq",
  "classconnfreq", "classmaxlinks", "classsendq", "classusermode",
  "connectblock", "@4", "connectitems", "connectitem", "connectname",
  "connectpass", "connectclass", "connecthost", "connectport",
  "connectvhost", "connectleaf", "connecthub", "connecthublimit",
  "connectmaxhops", "connectauto", "connectsecure", "uworldblock",
  "uworlditems", "uworlditem", "uworldname", "operblock", "operitems",
  "operitem", "opername", "operpass", "operhost", "operclass", "priv",
  "privtype", "yesorno", "address_family", "portblock", "portitems",
  "portitem", "portnumber", "portvhost", "portvhostnumber", "portmask",
  "portserver", "porthidden", "portsecure", "clientblock", "@5",
  "clientitems", "clientitem", "clienthost", "clientip", "clientusername",
  "clientclass", "clientpass", "clientmaxlinks", "clientport", "killblock",
  "@6", "killitems", "killitem", "killuhost", "killusername", "killreal",
  "killreason", "killreasonfile", "cruleblock", "@7", "cruleitems",
  "cruleitem", "cruleserver", "crulerule", "cruleall", "motdblock",
  "motditems", "motditem", "motdhost", "motdfile", "featuresblock",
  "featureitems", "featureitem", "@8", "stringlist", "extrastring",
  "quarantineblock", "quarantineitems", "quarantineitem", "pseudoblock",
  "@9", "pseudoitems", "pseudoitem", "pseudoname", "pseudoprepend",
  "pseudonick", "pseudoflags", "iauthblock", "iauthitems", "iauthitem",
  "iauthprogram", "@10", "iauthrequired", "forwardsblock", "@11",
  "forwarditems", "forwarditem", "webircblock", "@12", "webircitems",
  "webircitem", "webircpass", "webirchost", "webircnhost", "webircspoof",
  "webircnspoof", "webircname", "sslblock", "sslitems", "sslitem",
  "sslcert", "sslcacert", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,    43,    45,    42,    47,    59,    40,    41,
     123,   125,    61,    33
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   134,   135,   135,   136,   136,   136,   136,   136,   136,
     136,   136,   136,   136,   136,   136,   136,   136,   136,   136,
     136,   136,   136,   136,   137,   137,   138,   138,   139,   140,
     140,   140,   140,   140,   140,   140,   140,   141,   141,   141,
     141,   141,   141,   142,   142,   142,   142,   142,   142,   143,
     144,   144,   145,   146,   148,   147,   149,   149,   150,   150,
     150,   150,   150,   150,   151,   152,   153,   154,   155,   156,
     158,   157,   159,   159,   160,   160,   161,   162,   164,   163,
     165,   165,   166,   166,   166,   166,   166,   166,   166,   166,
     167,   168,   169,   170,   171,   172,   173,   175,   174,   176,
     176,   177,   177,   177,   177,   177,   177,   177,   177,   177,
     177,   177,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   188,   189,   189,   190,   191,   191,
     192,   193,   194,   195,   195,   196,   196,   196,   196,   196,
     197,   198,   199,   200,   201,   202,   202,   202,   202,   202,
     202,   202,   202,   202,   202,   202,   202,   202,   202,   202,
     202,   202,   202,   202,   202,   202,   202,   202,   202,   202,
     202,   202,   202,   202,   202,   202,   202,   202,   202,   202,
     202,   202,   202,   202,   202,   202,   202,   202,   202,   203,
     203,   204,   204,   204,   204,   204,   205,   206,   206,   207,
     207,   207,   207,   207,   207,   207,   208,   209,   210,   211,
     212,   212,   213,   213,   214,   214,   216,   215,   217,   217,
     218,   218,   218,   218,   218,   218,   218,   219,   220,   221,
     222,   223,   224,   225,   227,   226,   228,   228,   229,   229,
     229,   229,   229,   230,   231,   232,   233,   234,   236,   235,
     237,   237,   238,   238,   238,   239,   240,   241,   241,   242,
     243,   243,   244,   244,   245,   246,   247,   248,   248,   250,
     249,   251,   251,   252,   253,   254,   254,   255,   257,   256,
     258,   258,   259,   259,   259,   259,   260,   261,   262,   263,
     264,   265,   265,   266,   266,   268,   267,   269,   271,   270,
     272,   272,   273,   275,   274,   276,   276,   277,   277,   277,
     277,   277,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   285,   286,   286,   287,   288
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     1,     1,     2,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     2,
       2,     2,     2,     1,     3,     3,     3,     3,     3,     5,
       2,     1,     1,     4,     0,     6,     2,     1,     1,     1,
       1,     1,     1,     1,     4,     4,     4,     4,     6,     5,
       0,     6,     2,     1,     1,     1,     4,     4,     0,     6,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       4,     4,     4,     4,     4,     4,     4,     0,     6,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     4,     4,     4,     4,     4,     4,     2,
       2,     4,     4,     4,     4,     4,     4,     5,     2,     1,
       1,     4,     5,     1,     2,     1,     1,     1,     1,     1,
       4,     4,     4,     4,     4,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     0,     1,     1,     2,     2,     5,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     5,     5,     6,     4,
       4,     4,     4,     4,     4,     4,     0,     6,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     4,     4,     4,
       4,     4,     4,     4,     0,     6,     2,     1,     1,     1,
       1,     1,     1,     4,     4,     4,     4,     4,     0,     6,
       2,     1,     1,     1,     1,     4,     4,     4,     4,     5,
       2,     1,     1,     1,     4,     4,     5,     2,     1,     0,
       5,     2,     1,     1,     5,     2,     1,     4,     0,     7,
       2,     1,     1,     1,     1,     1,     4,     4,     4,     2,
       5,     2,     1,     1,     1,     0,     5,     4,     0,     6,
       2,     1,     4,     0,     6,     2,     1,     1,     1,     1,
       1,     1,     1,     4,     4,     5,     4,     5,     4,     5,
       2,     1,     1,     1,     4,     4
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     0,    54,    70,    97,    78,     0,     0,     0,     0,
       0,   216,   234,   248,     0,     0,     0,     0,   298,   303,
       0,     0,     3,    11,     5,     4,     6,     7,     8,     9,
      10,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     1,     2,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   198,   199,   200,   201,   202,
     203,   204,   205,     0,     0,   129,   130,     0,     0,     0,
       0,   184,   167,   160,   145,   146,   147,   148,   161,   162,
     163,   164,   165,   166,   168,   174,   169,   170,   171,   172,
     173,   175,   176,   177,   178,   179,   180,   181,   182,   185,
     186,   188,   183,   149,   155,   151,   152,   153,   154,   156,
     157,   158,   159,   150,   187,     0,   133,   135,   136,   137,
     138,   139,     0,     0,     0,     0,   261,   262,   263,     0,
       0,    51,    52,     0,     0,     0,   269,     0,   268,     0,
       0,   276,   278,     0,     0,     0,   292,   293,   294,     0,
       0,     0,     0,     0,   321,   322,   323,     0,     0,     0,
       0,     0,     0,    57,    58,    59,    61,    60,    62,    63,
       0,     0,     0,    73,    74,    75,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
     112,     0,     0,     0,     0,     0,     0,     0,     0,    81,
      82,    89,    83,    84,    85,    86,    87,    88,     0,   191,
       0,   191,     0,     0,     0,   197,     0,     0,   128,     0,
       0,     0,     0,     0,   134,     0,     0,     0,     0,   260,
       0,     0,    50,     0,     0,     0,     0,     0,     0,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,     0,
       0,     0,     0,     0,     0,   237,   238,   240,   239,   242,
     241,     0,     0,     0,     0,   251,   252,   253,   254,     0,
       0,   267,     0,     0,   275,     0,   295,     0,     0,   291,
       0,     0,   301,     0,     0,     0,     0,     0,   306,   307,
     308,   309,   310,   311,   312,     0,     0,     0,   320,     0,
       0,     0,     0,     0,     0,     0,    56,     0,     0,     0,
      72,     0,     0,     0,     0,     0,     0,   120,     0,   119,
       0,     0,     0,     0,    99,     0,     0,     0,     0,     0,
       0,     0,     0,    80,     0,     0,   192,   193,     0,     0,
       0,     0,     0,     0,     0,   196,     0,   127,     0,     0,
       0,     0,   132,   189,   190,     0,     0,     0,   259,     0,
      49,     0,     0,     0,     0,     0,     0,     0,     0,   218,
       0,     0,     0,     0,     0,     0,   236,     0,     0,     0,
       0,   250,     0,   266,     0,   274,     0,     0,     0,     0,
       0,   281,   282,   283,   284,   285,     0,     0,   290,     0,
       0,   300,     0,     0,     0,     0,     0,     0,     0,   305,
       0,     0,   319,     0,     0,     0,     0,     0,   191,    55,
       0,     0,    71,     0,    43,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    98,     0,    25,
      27,    24,     0,     0,     0,    37,     0,     0,     0,    79,
     210,   211,   194,   195,     0,   209,     0,   212,   213,   214,
     215,   131,   143,   140,   142,   141,   144,   264,   265,    53,
       0,     0,     0,     0,     0,     0,     0,   217,     0,     0,
       0,     0,     0,   235,     0,     0,     0,     0,   249,   273,
       0,   272,   277,     0,     0,     0,   289,     0,   280,     0,
     297,     0,   299,     0,     0,     0,     0,     0,     0,   304,
     324,   325,    65,    67,    64,    66,     0,     0,    76,    77,
     115,     0,     0,     0,     0,     0,   122,   113,   116,   114,
     117,   121,   118,   123,   124,   125,   126,    92,    26,     0,
      29,    30,    31,    32,    33,    34,    35,    36,    28,    93,
      94,    95,    38,    39,    40,    41,    42,    90,    96,    91,
     206,     0,   207,   230,   232,   227,   228,   229,   231,   233,
     243,   244,   245,   246,   247,   255,   256,   257,   258,   270,
     271,     0,     0,     0,   279,   296,   302,   318,   314,     0,
     313,   316,     0,    69,     0,    48,    44,    45,    46,    47,
     208,   286,   288,   287,   315,   317,    68
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    21,    22,   468,   469,   470,   578,   474,   471,    23,
     150,   151,   152,    24,    43,   182,   183,   184,   185,   186,
     187,   188,   189,    25,    44,   192,   193,   194,   195,    26,
      46,   228,   229,   230,   231,   232,   233,   234,   235,   236,
      27,    45,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   220,    28,    84,    85,    86,
      29,   135,   136,   137,   138,   139,   140,   141,   142,   385,
     368,    30,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    31,    52,   270,   271,   272,   273,   274,   275,   276,
     277,   278,    32,    53,   284,   285,   286,   287,   288,   289,
     290,    33,    54,   294,   295,   296,   297,   298,    34,   145,
     146,   147,   148,    35,   157,   158,   299,   520,   521,    36,
     160,   161,    37,   305,   420,   421,   422,   423,   424,   425,
      38,   165,   166,   167,   426,   168,    39,    59,   311,   312,
      40,    60,   317,   318,   319,   320,   321,   322,   323,   324,
      41,   173,   174,   175,   176
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -454
static const yytype_int16 yypact[] =
{
     480,  -104,  -454,  -454,  -454,  -454,  -103,   -96,   -64,   -53,
     -34,  -454,  -454,  -454,   -27,   -23,    97,   -21,  -454,  -454,
     -19,    37,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,   -16,   -10,    16,    22,    34,   122,   247,
      -5,    92,    25,    41,    56,   190,   191,    66,     4,    67,
      77,   -72,  -454,  -454,     3,    57,   130,   358,    73,    74,
     124,   134,   148,   149,    78,    34,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,   150,   136,   122,  -454,   151,   153,   154,
     155,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,   132,  -454,  -454,  -454,  -454,
    -454,  -454,   156,   157,   159,   161,    -5,  -454,  -454,   162,
     165,    92,  -454,   158,    31,   -14,  -454,     0,  -454,   166,
       1,  -454,  -454,   167,   169,   171,     4,  -454,  -454,   252,
      18,   172,   173,   -63,  -454,  -454,  -454,   174,   175,   176,
     177,    59,   179,     3,  -454,  -454,  -454,  -454,  -454,  -454,
     180,   181,    -1,  -454,  -454,  -454,   182,   183,   184,   185,
     186,   187,  -106,   163,   188,   189,   192,   194,   130,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,   195,   196,   241,   244,   245,   246,   249,   248,   358,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,    50,   -30,
     281,   -30,    63,    75,   170,  -454,   290,   199,  -454,   300,
     308,   319,   320,   255,  -454,    83,   380,   381,   258,  -454,
     383,   260,  -454,   256,   257,   259,   261,   262,   263,   264,
     266,   158,  -454,  -454,  -454,  -454,  -454,  -454,  -454,   267,
     268,   269,   270,   271,   273,    31,  -454,  -454,  -454,  -454,
    -454,   275,   276,   277,   274,   -14,  -454,  -454,  -454,   278,
     265,  -454,   387,   285,  -454,    52,  -454,    83,   286,  -454,
     282,     2,  -454,   283,    -4,   284,    11,     7,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,   395,   414,   291,  -454,   416,
     417,   419,   418,   292,   293,   299,  -454,   424,   425,   302,
    -454,   427,     6,   428,   429,   430,   432,  -454,   431,  -454,
     434,   118,   120,   311,  -454,     6,     6,     6,     6,   436,
     479,     6,   356,  -454,   357,   360,   420,   422,   484,   366,
     491,   368,   369,   370,   371,  -454,   372,  -454,   373,   374,
     375,   376,  -454,  -454,  -454,   377,   378,   379,  -454,   382,
    -454,   504,     6,   505,   507,   508,   509,     6,   386,  -454,
     511,   512,   513,   515,   516,   393,  -454,   519,   520,   123,
     398,  -454,   523,  -454,   402,  -454,   399,   403,   404,   410,
     407,    52,  -454,  -454,  -454,  -454,   523,   412,  -454,   527,
     421,  -454,   540,   541,   415,   543,   546,   426,   423,  -454,
     433,   435,  -454,   437,   438,   439,   440,   548,   -30,  -454,
     441,   442,  -454,   443,  -454,     6,    65,   444,   445,   446,
     447,   448,   449,   450,   451,   452,   453,  -454,   454,     6,
    -454,    33,   455,    76,   456,    -2,   457,   458,   135,  -454,
    -454,  -454,  -454,  -454,   459,  -454,    10,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
     460,   147,   461,   462,   463,   464,   152,  -454,   465,   466,
     467,   468,   469,  -454,   470,   471,   472,   473,  -454,  -454,
       8,  -454,  -454,   549,   551,   553,  -454,   474,  -454,     9,
    -454,   475,  -454,   476,   477,   554,   478,   481,   558,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,   482,   560,  -454,  -454,
    -454,    58,     6,     6,     6,     6,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,    33,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,   483,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,   485,   486,   487,  -454,  -454,  -454,  -454,  -454,   488,
    -454,  -454,   489,  -454,   490,  -454,    48,    48,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -454,  -454,   585,   251,  -454,   142,  -454,  -454,  -342,  -454,
     492,  -454,  -454,  -454,  -454,   493,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,   494,  -454,  -454,  -454,
    -454,   389,  -454,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,   411,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,  -454,  -454,  -454,   535,  -454,  -454,
    -454,  -454,   495,  -454,  -454,  -454,  -454,   -65,  -454,   314,
    -240,  -454,   547,  -454,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,   352,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,  -454,   339,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,  -454,   330,  -454,  -454,  -454,  -454,  -454,   496,
    -454,  -454,  -454,  -454,  -454,   497,  -454,   200,  -453,  -454,
    -454,   498,  -454,  -454,   206,  -454,  -454,  -454,  -454,  -454,
    -454,   499,  -454,  -454,  -454,  -454,  -454,  -454,  -454,   317,
    -454,  -454,  -454,   312,  -454,  -454,  -454,  -454,  -454,  -454,
    -454,  -454,   500,  -454,  -454
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint16 yytable[] =
{
     456,   370,   237,   156,   159,   310,   190,   191,   171,   172,
     454,   519,   519,   143,   591,   473,   475,   171,   172,   478,
     177,   347,   291,    42,   313,   314,   348,    47,   315,   582,
     583,   584,   585,   586,    48,   313,   314,    62,     1,   315,
     366,   367,     2,     3,   292,   293,     4,     5,   178,   279,
     501,   280,   144,   179,   180,   506,   570,   571,   572,   573,
     574,   575,   576,   577,   190,   191,    49,   610,   327,   416,
      68,    69,    70,   163,     6,   181,   610,    50,     7,    71,
      72,     8,   164,   316,     9,    10,   281,   282,   283,    11,
      12,    13,   364,   365,   316,   333,    51,    14,    15,    16,
      57,   417,    17,    55,   334,   371,   372,    56,    73,    58,
      18,    61,    19,   551,    64,   418,    20,   373,   374,   419,
      65,   552,   553,   554,   555,   383,   384,   569,   433,   434,
     339,   300,   303,   430,   455,   609,   615,   592,   438,    83,
     196,   149,    87,   436,   437,   197,    66,   198,   199,    88,
      89,   200,    67,    90,    91,   153,   552,   553,   554,   555,
     463,   464,   465,   466,   237,   516,   517,   201,   263,   202,
     203,   154,   264,   554,   555,   204,   265,   266,   267,   268,
      92,   552,   553,   554,   555,    93,   155,   625,   552,   553,
     554,   555,   556,   156,   159,   269,   162,   169,   205,   552,
     553,   554,   555,   580,   206,   238,   239,   170,   547,   244,
     626,   627,   628,   629,    94,    95,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   310,   240,    87,   552,   553,
     554,   555,   589,   253,    88,    89,   241,   247,    90,    91,
     552,   553,   554,   555,   594,   552,   553,   554,   555,   599,
     242,   243,   246,   249,   369,   250,   251,   252,   255,   256,
     349,   257,   258,   376,   260,    92,   261,   375,   302,   306,
      93,   307,   308,   378,   325,   326,   329,   330,   331,   332,
     335,   379,   337,   338,   341,   342,   343,   344,   345,   346,
     350,   351,   380,   381,   352,   353,   377,   355,   356,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     221,   222,   223,   357,   224,   225,   358,   359,   360,   362,
      91,   361,   382,   386,   387,   388,   389,   390,   391,   392,
     414,   393,   413,   394,   395,   396,   397,   398,   440,   400,
     401,   402,   403,   404,   405,   410,    92,   407,   408,   409,
     412,    93,   415,   428,   429,   432,   435,   441,   442,   443,
     444,   446,   226,   445,   447,   448,   449,   450,   451,   452,
     453,   457,   458,   459,   461,   227,   460,   462,   467,   476,
      94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,     1,   477,   479,   480,     2,     3,   481,   484,     4,
       5,   482,   483,   485,   486,   487,   488,   489,   490,   491,
     492,   493,   494,   495,   496,   497,   498,   500,   502,   499,
     503,   504,   505,   507,   508,   509,   510,     6,   511,   512,
     513,     7,   514,   515,     8,   518,   519,     9,    10,   522,
     531,   523,    11,    12,    13,   524,   525,   526,   527,   530,
      14,    15,    16,   533,   534,    17,   536,   535,   532,   537,
     539,   546,   611,    18,   612,    19,   613,   619,   538,    20,
     540,   622,   541,   624,   542,   543,   544,   545,   548,   549,
     550,   557,   558,   559,   560,   561,   562,   563,   564,   565,
     566,   567,   579,   581,   587,   588,   590,   593,   595,   596,
     597,   598,   600,   601,   602,   603,   604,   605,   606,   607,
     608,   614,   616,   617,   618,   620,    63,   472,   621,   623,
     630,   568,   631,   632,   633,   634,   635,   636,   363,   354,
     248,   427,   245,   399,   406,   411,   529,   528,   431,   439,
     254,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   259,   262,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   301,     0,     0,     0,   304,     0,
       0,     0,     0,     0,     0,   309,     0,     0,     0,     0,
       0,     0,     0,   328,     0,     0,   336,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   340
};

static const yytype_int16 yycheck[] =
{
     342,   241,    67,     3,     3,     3,     7,     8,    80,    81,
       4,     3,     3,    18,     4,   357,   358,    80,    81,   361,
      17,   127,    36,   127,    17,    18,   132,   130,    21,    31,
      32,    33,    34,    35,   130,    17,    18,     0,     1,    21,
      70,    71,     5,     6,    58,    59,     9,    10,    45,    18,
     392,    20,    57,    50,    51,   397,    23,    24,    25,    26,
      27,    28,    29,    30,     7,     8,   130,   520,   131,    17,
      36,    37,    38,    69,    37,    72,   529,   130,    41,    45,
      46,    44,    78,    76,    47,    48,    55,    56,    57,    52,
      53,    54,    42,    43,    76,    36,   130,    60,    61,    62,
       3,    49,    65,   130,    45,    42,    43,   130,    74,   130,
      73,   130,    75,   455,   130,    63,    79,    42,    43,    67,
     130,   123,   124,   125,   126,    42,    43,   469,   132,   133,
     131,   131,   131,   131,   128,   127,   127,   127,   131,    17,
      10,    49,    10,   132,   133,    15,   130,    17,    18,    17,
      18,    21,   130,    21,    22,   130,   123,   124,   125,   126,
      42,    43,    42,    43,   229,    42,    43,    37,    10,    39,
      40,   130,    14,   125,   126,    45,    18,    19,    20,    21,
      48,   123,   124,   125,   126,    53,   130,   129,   123,   124,
     125,   126,   127,     3,     3,    37,   130,   130,    68,   123,
     124,   125,   126,   127,    74,   132,   132,   130,   448,   131,
     552,   553,   554,   555,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,     3,   132,    10,   123,   124,
     125,   126,   127,   131,    17,    18,   132,   131,    21,    22,
     123,   124,   125,   126,   127,   123,   124,   125,   126,   127,
     132,   132,   132,   132,     3,   132,   132,   132,   132,   132,
     127,   132,   131,     3,   132,    48,   131,   127,   132,   132,
      53,   132,   131,     3,   132,   132,   132,   132,   132,   132,
     131,     3,   132,   132,   132,   132,   132,   132,   132,   132,
     132,   132,     3,     3,   132,   131,   127,   132,   132,    82,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
      12,    13,    14,   132,    16,    17,   132,   132,   132,   131,
      22,   132,   127,     3,     3,   127,     3,   127,   132,   132,
       3,   132,   127,   132,   132,   132,   132,   131,     3,   132,
     132,   132,   132,   132,   131,   131,    48,   132,   132,   132,
     132,    53,   127,   127,   132,   132,   132,     3,   127,     3,
       3,     3,    64,     4,   132,   132,   127,     3,     3,   127,
       3,     3,     3,     3,     3,    77,     4,     3,   127,     3,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
     122,     1,     3,   127,   127,     5,     6,   127,     4,     9,
      10,    71,    70,   127,     3,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,     3,     3,   127,
       3,     3,     3,   127,     3,     3,     3,    37,     3,     3,
     127,    41,     3,     3,    44,   127,     3,    47,    48,   127,
       3,   132,    52,    53,    54,   132,   132,   127,   131,   127,
      60,    61,    62,     3,     3,    65,     3,   132,   127,     3,
     127,     3,     3,    73,     3,    75,     3,     3,   132,    79,
     127,     3,   127,     3,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,    21,   356,   127,   127,
     127,   469,   127,   127,   127,   127,   127,   127,   229,   208,
      85,   307,    75,   271,   285,   295,   426,   421,   311,   317,
     135,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   146,   151,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   157,    -1,    -1,    -1,   160,    -1,
      -1,    -1,    -1,    -1,    -1,   166,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   173,    -1,    -1,   183,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   192
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     1,     5,     6,     9,    10,    37,    41,    44,    47,
      48,    52,    53,    54,    60,    61,    62,    65,    73,    75,
      79,   135,   136,   143,   147,   157,   163,   174,   190,   194,
     205,   215,   226,   235,   242,   247,   253,   256,   264,   270,
     274,   284,   127,   148,   158,   175,   164,   130,   130,   130,
     130,   130,   216,   227,   236,   130,   130,     3,   130,   271,
     275,   130,     0,   136,   130,   130,   130,   130,    36,    37,
      38,    45,    46,    74,   206,   207,   208,   209,   210,   211,
     212,   213,   214,    17,   191,   192,   193,    10,    17,    18,
      21,    22,    48,    53,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   195,   196,   197,   198,   199,
     200,   201,   202,    18,    57,   243,   244,   245,   246,    49,
     144,   145,   146,   130,   130,   130,     3,   248,   249,     3,
     254,   255,   130,    69,    78,   265,   266,   267,   269,   130,
     130,    80,    81,   285,   286,   287,   288,    17,    45,    50,
      51,    72,   149,   150,   151,   152,   153,   154,   155,   156,
       7,     8,   159,   160,   161,   162,    10,    15,    17,    18,
      21,    37,    39,    40,    45,    68,    74,   176,   177,   178,
     179,   180,   181,   182,   183,   184,   185,   186,   187,   188,
     189,    12,    13,    14,    16,    17,    64,    77,   165,   166,
     167,   168,   169,   170,   171,   172,   173,   201,   132,   132,
     132,   132,   132,   132,   131,   206,   132,   131,   191,   132,
     132,   132,   132,   131,   196,   132,   132,   132,   131,   243,
     132,   131,   144,    10,    14,    18,    19,    20,    21,    37,
     217,   218,   219,   220,   221,   222,   223,   224,   225,    18,
      20,    55,    56,    57,   228,   229,   230,   231,   232,   233,
     234,    36,    58,    59,   237,   238,   239,   240,   241,   250,
     131,   249,   132,   131,   255,   257,   132,   132,   131,   265,
       3,   272,   273,    17,    18,    21,    76,   276,   277,   278,
     279,   280,   281,   282,   283,   132,   132,   131,   286,   132,
     132,   132,   132,    36,    45,   131,   149,   132,   132,   131,
     160,   132,   132,   132,   132,   132,   132,   127,   132,   127,
     132,   132,   132,   131,   176,   132,   132,   132,   132,   132,
     132,   132,   131,   165,    42,    43,    70,    71,   204,     3,
     204,    42,    43,    42,    43,   127,     3,   127,     3,     3,
       3,     3,   127,    42,    43,   203,     3,     3,   127,     3,
     127,   132,   132,   132,   132,   132,   132,   132,   131,   217,
     132,   132,   132,   132,   132,   131,   228,   132,   132,   132,
     131,   237,   132,   127,     3,   127,    17,    49,    63,    67,
     258,   259,   260,   261,   262,   263,   268,   203,   127,   132,
     131,   273,   132,   132,   133,   132,   132,   133,   131,   277,
       3,     3,   127,     3,     3,     4,     3,   132,   132,   127,
       3,     3,   127,     3,     4,   128,   142,     3,     3,     3,
       4,     3,     3,    42,    43,    42,    43,   127,   137,   138,
     139,   142,   137,   142,   141,   142,     3,     3,   142,   127,
     127,   127,    71,    70,     4,   127,     3,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
       3,   142,     3,     3,     3,     3,   142,   127,     3,     3,
       3,     3,     3,   127,     3,     3,    42,    43,   127,     3,
     251,   252,   127,   132,   132,   132,   127,   131,   258,   251,
     127,     3,   127,     3,     3,   132,     3,     3,   132,   127,
     127,   127,   127,   127,   127,   127,     3,   204,   127,   127,
     127,   142,   123,   124,   125,   126,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   139,   142,
      23,    24,    25,    26,    27,    28,    29,    30,   140,   127,
     127,   127,    31,    32,    33,    34,    35,   127,   127,   127,
     127,     4,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     252,     3,     3,     3,   127,   127,   127,   127,   127,     3,
     127,   127,     3,   127,     3,   129,   142,   142,   142,   142,
     127,   127,   127,   127,   127,   127,   127
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 26:
#line 225 "./ircd_parser.y"
    {
  (yyval.num) = (yyvsp[(1) - (2)].num) + (yyvsp[(2) - (2)].num);
}
    break;

  case 28:
#line 230 "./ircd_parser.y"
    {
  (yyval.num) = (yyvsp[(1) - (2)].num) * (yyvsp[(2) - (2)].num);
}
    break;

  case 29:
#line 234 "./ircd_parser.y"
    { (yyval.num) = 1; }
    break;

  case 30:
#line 235 "./ircd_parser.y"
    { (yyval.num) = 60; }
    break;

  case 31:
#line 236 "./ircd_parser.y"
    { (yyval.num) = 60 * 60; }
    break;

  case 32:
#line 237 "./ircd_parser.y"
    { (yyval.num) = 60 * 60 * 24; }
    break;

  case 33:
#line 238 "./ircd_parser.y"
    { (yyval.num) = 60 * 60 * 24 * 7; }
    break;

  case 34:
#line 239 "./ircd_parser.y"
    { (yyval.num) = 60 * 60 * 24 * 7 * 4; }
    break;

  case 35:
#line 240 "./ircd_parser.y"
    { (yyval.num) = 60 * 60 * 24 * 365; }
    break;

  case 36:
#line 241 "./ircd_parser.y"
    { (yyval.num) = 60 * 60 * 24 * 365 * 10; }
    break;

  case 37:
#line 244 "./ircd_parser.y"
    {
			(yyval.num) = (yyvsp[(1) - (1)].num);
		}
    break;

  case 38:
#line 247 "./ircd_parser.y"
    { 
			(yyval.num) = (yyvsp[(1) - (2)].num);
		}
    break;

  case 39:
#line 250 "./ircd_parser.y"
    {
			(yyval.num) = (yyvsp[(1) - (2)].num) * 1024;
		}
    break;

  case 40:
#line 253 "./ircd_parser.y"
    {
			(yyval.num) = (yyvsp[(1) - (2)].num) * 1024 * 1024;
		}
    break;

  case 41:
#line 256 "./ircd_parser.y"
    {
			(yyval.num) = (yyvsp[(1) - (2)].num) * 1024 * 1024 * 1024;
		}
    break;

  case 42:
#line 259 "./ircd_parser.y"
    {
			(yyval.num) = (yyvsp[(1) - (2)].num) * 1024 * 1024 * 1024;
		}
    break;

  case 43:
#line 266 "./ircd_parser.y"
    { 
			(yyval.num) = (yyvsp[(1) - (1)].num);
		}
    break;

  case 44:
#line 269 "./ircd_parser.y"
    { 
			(yyval.num) = (yyvsp[(1) - (3)].num) + (yyvsp[(3) - (3)].num);
		}
    break;

  case 45:
#line 272 "./ircd_parser.y"
    { 
			(yyval.num) = (yyvsp[(1) - (3)].num) - (yyvsp[(3) - (3)].num);
		}
    break;

  case 46:
#line 275 "./ircd_parser.y"
    { 
			(yyval.num) = (yyvsp[(1) - (3)].num) * (yyvsp[(3) - (3)].num);
		}
    break;

  case 47:
#line 278 "./ircd_parser.y"
    { 
			(yyval.num) = (yyvsp[(1) - (3)].num) / (yyvsp[(3) - (3)].num);
		}
    break;

  case 48:
#line 285 "./ircd_parser.y"
    {
			(yyval.num) = (yyvsp[(2) - (3)].num);
		}
    break;

  case 53:
#line 294 "./ircd_parser.y"
    {
  addNickJupes((yyvsp[(3) - (4)].text));
  MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 54:
#line 300 "./ircd_parser.y"
    {
    /* Zero out the vhost addresses, in case they were removed. */
    memset(&VirtualHost_v4.addr, 0, sizeof(VirtualHost_v4.addr));
    memset(&VirtualHost_v6.addr, 0, sizeof(VirtualHost_v6.addr));
}
    break;

  case 55:
#line 304 "./ircd_parser.y"
    {
  if (localConf.name == NULL)
    parse_error("Your General block must contain a name.");
  if (localConf.numeric == 0)
    parse_error("Your General block must contain a numeric (between 1 and 4095).");
}
    break;

  case 64:
#line 315 "./ircd_parser.y"
    {
  if (localConf.numeric == 0)
    localConf.numeric = (yyvsp[(3) - (4)].num);
  else if (localConf.numeric != (yyvsp[(3) - (4)].num))
    parse_error("Redefinition of server numeric %i (%i)", (yyvsp[(3) - (4)].num),
    		localConf.numeric);
}
    break;

  case 65:
#line 324 "./ircd_parser.y"
    {
  if (localConf.name == NULL)
    localConf.name = (yyvsp[(3) - (4)].text);
  else {
    if (strcmp(localConf.name, (yyvsp[(3) - (4)].text)))
      parse_error("Redefinition of server name %s (%s)", (yyvsp[(3) - (4)].text),
                  localConf.name);
    MyFree((yyvsp[(3) - (4)].text));
  }
}
    break;

  case 66:
#line 336 "./ircd_parser.y"
    {
  MyFree(localConf.description);
  localConf.description = (yyvsp[(3) - (4)].text);
  ircd_strncpy(cli_info(&me), (yyvsp[(3) - (4)].text), REALLEN);
}
    break;

  case 67:
#line 343 "./ircd_parser.y"
    {
  struct irc_in_addr addr;
  char *vhost = (yyvsp[(3) - (4)].text);

  if (!strcmp(vhost, "*")) {
    /* This traditionally meant bind to all interfaces and connect
     * from the default. */
  } else if (!ircd_aton(&addr, vhost))
    parse_error("Invalid virtual host '%s'.", vhost);
  else if (irc_in_addr_is_ipv4(&addr))
    memcpy(&VirtualHost_v4.addr, &addr, sizeof(addr));
  else
    memcpy(&VirtualHost_v6.addr, &addr, sizeof(addr));
  MyFree(vhost);
}
    break;

  case 68:
#line 360 "./ircd_parser.y"
    {
  struct irc_in_addr addr;
  int families = (yyvsp[(4) - (6)].num);
  char *vhost = (yyvsp[(5) - (6)].text);

  if (!strcmp(vhost, "*")) {
    /* Let the operating system assign the default. */
  } else if (!ircd_aton(&addr, vhost))
    parse_error("Invalid DNS virtual host '%s'.", vhost);
  else
  {
    if ((families & USE_IPV4)
        || (!families && irc_in_addr_is_ipv4(&addr)))
      memcpy(&VirtualHost_dns_v4.addr, &addr, sizeof(addr));
    if ((families & USE_IPV6)
        || (!families && !irc_in_addr_is_ipv4(&addr)))
      memcpy(&VirtualHost_dns_v6.addr, &addr, sizeof(addr));
  }
  MyFree(vhost);
}
    break;

  case 69:
#line 382 "./ircd_parser.y"
    {
  char *server = (yyvsp[(4) - (5)].text);

  add_nameserver(server);
  MyFree(server);
}
    break;

  case 70:
#line 390 "./ircd_parser.y"
    {
  MyFree(localConf.location1);
  MyFree(localConf.location2);
  MyFree(localConf.contact);
  localConf.location1 = localConf.location2 = localConf.contact = NULL;
}
    break;

  case 71:
#line 397 "./ircd_parser.y"
    {
  if (localConf.location1 == NULL)
    DupString(localConf.location1, "");
  if (localConf.location2 == NULL)
    DupString(localConf.location2, "");
  if (localConf.contact == NULL)
    DupString(localConf.contact, "");
}
    break;

  case 76:
#line 408 "./ircd_parser.y"
    {
  if (localConf.location1 == NULL)
    localConf.location1 = (yyvsp[(3) - (4)].text);
  else if (localConf.location2 == NULL)
    localConf.location2 = (yyvsp[(3) - (4)].text);
  else /* Otherwise just drop it. -A1kmm */
    MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 77:
#line 417 "./ircd_parser.y"
    {
 MyFree(localConf.contact);
 localConf.contact = (yyvsp[(3) - (4)].text);
}
    break;

  case 78:
#line 422 "./ircd_parser.y"
    {
  tping = 90;
  maxchans = 0;
}
    break;

  case 79:
#line 426 "./ircd_parser.y"
    {
  if (name != NULL)
  {
    struct ConnectionClass *c_class;
    add_class(name, tping, tconn, maxlinks, sendq, maxchans);
    c_class = find_class(name);
    MyFree(c_class->default_umode);
    c_class->default_umode = pass;
    memcpy(&c_class->privs, &privs, sizeof(c_class->privs));
    memcpy(&c_class->privs_dirty, &privs_dirty, sizeof(c_class->privs_dirty));
  }
  else {
   parse_error("Missing name in class block");
  }
  name = NULL;
  pass = NULL;
  tconn = 0;
  maxlinks = 0;
  sendq = 0;
  memset(&privs, 0, sizeof(privs));
  memset(&privs_dirty, 0, sizeof(privs_dirty));
}
    break;

  case 90:
#line 452 "./ircd_parser.y"
    {
  MyFree(name);
  name = (yyvsp[(3) - (4)].text);
}
    break;

  case 91:
#line 457 "./ircd_parser.y"
    {
  maxchans = (yyvsp[(3) - (4)].num);
}
    break;

  case 92:
#line 461 "./ircd_parser.y"
    {
  tping = (yyvsp[(3) - (4)].num);
}
    break;

  case 93:
#line 465 "./ircd_parser.y"
    {
  tconn = (yyvsp[(3) - (4)].num);
}
    break;

  case 94:
#line 469 "./ircd_parser.y"
    {
  maxlinks = (yyvsp[(3) - (4)].num);
}
    break;

  case 95:
#line 473 "./ircd_parser.y"
    {
  sendq = (yyvsp[(3) - (4)].num);
}
    break;

  case 96:
#line 477 "./ircd_parser.y"
    {
  MyFree(pass);
  pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 97:
#line 483 "./ircd_parser.y"
    {
 flags = CONF_AUTOCONNECT;
}
    break;

  case 98:
#line 486 "./ircd_parser.y"
    {
 struct ConfItem *aconf = NULL;
 if (name == NULL)
  parse_error("Missing name in connect block");
 else if (pass == NULL)
  parse_error("Missing password in connect block");
 else if (strlen(pass) > PASSWDLEN)
  parse_error("Password too long in connect block");
 else if (host == NULL)
  parse_error("Missing host in connect block");
 else if (strchr(host, '*') || strchr(host, '?'))
  parse_error("Invalid host '%s' in connect block", host);
 else if (c_class == NULL)
  parse_error("Missing or non-existent class in connect block");
 else {
   aconf = make_conf(CONF_SERVER);
   aconf->name = name;
   aconf->origin_name = origin;
   aconf->passwd = pass;
   aconf->conn_class = c_class;
   aconf->address.port = port;
   aconf->host = host;
   /* If the user specified a hub allowance, but not maximum links,
    * allow an effectively unlimited number of hops.
    */
   aconf->maximum = (hub_limit != NULL && maxlinks == 0) ? 65535 : maxlinks;
   aconf->hub_limit = hub_limit;
   aconf->flags = flags;
   lookup_confhost(aconf);
 }
 if (!aconf) {
   MyFree(name);
   MyFree(pass);
   MyFree(host);
   MyFree(origin);
   MyFree(hub_limit);
 }
 name = pass = host = origin = hub_limit = NULL;
 c_class = NULL;
 port = flags = maxlinks = 0;
}
    break;

  case 113:
#line 532 "./ircd_parser.y"
    {
 MyFree(name);
 name = (yyvsp[(3) - (4)].text);
}
    break;

  case 114:
#line 537 "./ircd_parser.y"
    {
 MyFree(pass);
 pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 115:
#line 542 "./ircd_parser.y"
    {
 c_class = find_class((yyvsp[(3) - (4)].text));
 if (!c_class)
  parse_error("No such connection class '%s' for Connect block", (yyvsp[(3) - (4)].text));
 MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 116:
#line 549 "./ircd_parser.y"
    {
 MyFree(host);
 host = (yyvsp[(3) - (4)].text);
}
    break;

  case 117:
#line 554 "./ircd_parser.y"
    {
 port = (yyvsp[(3) - (4)].num);
}
    break;

  case 118:
#line 558 "./ircd_parser.y"
    {
 MyFree(origin);
 origin = (yyvsp[(3) - (4)].text);
}
    break;

  case 119:
#line 563 "./ircd_parser.y"
    {
 maxlinks = 0;
}
    break;

  case 120:
#line 567 "./ircd_parser.y"
    {
 MyFree(hub_limit);
 DupString(hub_limit, "*");
}
    break;

  case 121:
#line 572 "./ircd_parser.y"
    {
 MyFree(hub_limit);
 hub_limit = (yyvsp[(3) - (4)].text);
}
    break;

  case 122:
#line 577 "./ircd_parser.y"
    {
  maxlinks = (yyvsp[(3) - (4)].num);
}
    break;

  case 123:
#line 580 "./ircd_parser.y"
    { flags |= CONF_AUTOCONNECT; }
    break;

  case 124:
#line 581 "./ircd_parser.y"
    { flags &= ~CONF_AUTOCONNECT; }
    break;

  case 125:
#line 582 "./ircd_parser.y"
    { flags |= CONF_SECURE; }
    break;

  case 126:
#line 583 "./ircd_parser.y"
    { flags &= ~CONF_SECURE; }
    break;

  case 131:
#line 589 "./ircd_parser.y"
    {
  make_conf(CONF_UWORLD)->host = (yyvsp[(3) - (4)].text);
}
    break;

  case 132:
#line 594 "./ircd_parser.y"
    {
  struct ConfItem *aconf = NULL;
  struct SLink *link;

  if (name == NULL)
    parse_error("Missing name in operator block");
  else if (pass == NULL)
    parse_error("Missing password in operator block");
  /* Do not check password length because it may be crypted. */
  else if (hosts == NULL)
    parse_error("Missing host(s) in operator block");
  else if (c_class == NULL)
    parse_error("Invalid or missing class in operator block");
  else if (!FlagHas(&privs_dirty, PRIV_PROPAGATE)
           && !FlagHas(&c_class->privs_dirty, PRIV_PROPAGATE))
    parse_error("Operator block for %s and class %s have no LOCAL setting", name, c_class->cc_name);
  else for (link = hosts; link != NULL; link = link->next) {
    aconf = make_conf(CONF_OPERATOR);
    DupString(aconf->name, name);
    DupString(aconf->passwd, pass);
    conf_parse_userhost(aconf, link->value.cp);
    aconf->conn_class = c_class;
    memcpy(&aconf->privs, &privs, sizeof(aconf->privs));
    memcpy(&aconf->privs_dirty, &privs_dirty, sizeof(aconf->privs_dirty));
  }
  MyFree(name);
  MyFree(pass);
  free_slist(&hosts);
  name = pass = NULL;
  c_class = NULL;
  memset(&privs, 0, sizeof(privs));
  memset(&privs_dirty, 0, sizeof(privs_dirty));
}
    break;

  case 140:
#line 630 "./ircd_parser.y"
    {
  MyFree(name);
  name = (yyvsp[(3) - (4)].text);
}
    break;

  case 141:
#line 635 "./ircd_parser.y"
    {
  MyFree(pass);
  pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 142:
#line 640 "./ircd_parser.y"
    {
 struct SLink *link;
 link = make_link();
 if (!strchr((yyvsp[(3) - (4)].text), '@'))
 {
   int uh_len;
   link->value.cp = (char*) MyMalloc((uh_len = strlen((yyvsp[(3) - (4)].text))+3));
   ircd_snprintf(0, link->value.cp, uh_len, "*@%s", (yyvsp[(3) - (4)].text));
 }
 else
   DupString(link->value.cp, (yyvsp[(3) - (4)].text));
 MyFree((yyvsp[(3) - (4)].text));
 link->next = hosts;
 hosts = link;
}
    break;

  case 143:
#line 656 "./ircd_parser.y"
    {
 c_class = find_class((yyvsp[(3) - (4)].text));
 if (!c_class)
  parse_error("No such connection class '%s' for Operator block", (yyvsp[(3) - (4)].text));
 MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 144:
#line 664 "./ircd_parser.y"
    {
  FlagSet(&privs_dirty, (yyvsp[(1) - (4)].num));
  if (((yyvsp[(3) - (4)].num) == 1) ^ invert)
    FlagSet(&privs, (yyvsp[(1) - (4)].num));
  else
    FlagClr(&privs, (yyvsp[(1) - (4)].num));
  invert = 0;
}
    break;

  case 145:
#line 673 "./ircd_parser.y"
    { (yyval.num) = PRIV_CHAN_LIMIT; }
    break;

  case 146:
#line 674 "./ircd_parser.y"
    { (yyval.num) = PRIV_MODE_LCHAN; }
    break;

  case 147:
#line 675 "./ircd_parser.y"
    { (yyval.num) = PRIV_DEOP_LCHAN; }
    break;

  case 148:
#line 676 "./ircd_parser.y"
    { (yyval.num) = PRIV_WALK_LCHAN; }
    break;

  case 149:
#line 677 "./ircd_parser.y"
    { (yyval.num) = PRIV_SEE_IDLETIME; }
    break;

  case 150:
#line 678 "./ircd_parser.y"
    { (yyval.num) = PRIV_HIDE_IDLETIME; }
    break;

  case 151:
#line 679 "./ircd_parser.y"
    { (yyval.num) = PRIV_UMODE_NOCHAN; }
    break;

  case 152:
#line 680 "./ircd_parser.y"
    { (yyval.num) = PRIV_UMODE_NOIDLE; }
    break;

  case 153:
#line 681 "./ircd_parser.y"
    { (yyval.num) = PRIV_UMODE_CHSERV; }
    break;

  case 154:
#line 682 "./ircd_parser.y"
    { (yyval.num) = PRIV_UMODE_XTRAOP; }
    break;

  case 155:
#line 683 "./ircd_parser.y"
    { (yyval.num) = PRIV_UMODE_NETSERV; }
    break;

  case 156:
#line 684 "./ircd_parser.y"
    { (yyval.num) = PRIV_FLOOD; }
    break;

  case 157:
#line 685 "./ircd_parser.y"
    { (yyval.num) = PRIV_HALFFLOOD; }
    break;

  case 158:
#line 686 "./ircd_parser.y"
    { (yyval.num) = PRIV_UNLIMITED_TARGET; }
    break;

  case 159:
#line 687 "./ircd_parser.y"
    { (yyval.num) = PRIV_UMODE_OVERRIDECC; }
    break;

  case 160:
#line 688 "./ircd_parser.y"
    { (yyval.num) = PRIV_KILL; }
    break;

  case 161:
#line 689 "./ircd_parser.y"
    { (yyval.num) = PRIV_LOCAL_KILL; }
    break;

  case 162:
#line 690 "./ircd_parser.y"
    { (yyval.num) = PRIV_REHASH; }
    break;

  case 163:
#line 691 "./ircd_parser.y"
    { (yyval.num) = PRIV_RESTART; }
    break;

  case 164:
#line 692 "./ircd_parser.y"
    { (yyval.num) = PRIV_DIE; }
    break;

  case 165:
#line 693 "./ircd_parser.y"
    { (yyval.num) = PRIV_GLINE; }
    break;

  case 166:
#line 694 "./ircd_parser.y"
    { (yyval.num) = PRIV_LOCAL_GLINE; }
    break;

  case 167:
#line 695 "./ircd_parser.y"
    { (yyval.num) = PRIV_JUPE; }
    break;

  case 168:
#line 696 "./ircd_parser.y"
    { (yyval.num) = PRIV_LOCAL_JUPE; }
    break;

  case 169:
#line 697 "./ircd_parser.y"
    { (yyval.num) = PRIV_LOCAL_OPMODE; }
    break;

  case 170:
#line 698 "./ircd_parser.y"
    { (yyval.num) = PRIV_OPMODE; }
    break;

  case 171:
#line 699 "./ircd_parser.y"
    { (yyval.num) = PRIV_SET; }
    break;

  case 172:
#line 700 "./ircd_parser.y"
    { (yyval.num) = PRIV_WHOX; }
    break;

  case 173:
#line 701 "./ircd_parser.y"
    { (yyval.num) = PRIV_BADCHAN; }
    break;

  case 174:
#line 702 "./ircd_parser.y"
    { (yyval.num) = PRIV_LOCAL_BADCHAN; }
    break;

  case 175:
#line 703 "./ircd_parser.y"
    { (yyval.num) = PRIV_SEE_CHAN; }
    break;

  case 176:
#line 704 "./ircd_parser.y"
    { (yyval.num) = PRIV_SHOW_INVIS; }
    break;

  case 177:
#line 705 "./ircd_parser.y"
    { (yyval.num) = PRIV_SHOW_ALL_INVIS; }
    break;

  case 178:
#line 706 "./ircd_parser.y"
    { (yyval.num) = PRIV_PROPAGATE; }
    break;

  case 179:
#line 707 "./ircd_parser.y"
    { (yyval.num) = PRIV_UNLIMIT_QUERY; }
    break;

  case 180:
#line 708 "./ircd_parser.y"
    { (yyval.num) = PRIV_DISPLAY; }
    break;

  case 181:
#line 709 "./ircd_parser.y"
    { (yyval.num) = PRIV_SEE_OPERS; }
    break;

  case 182:
#line 710 "./ircd_parser.y"
    { (yyval.num) = PRIV_WIDE_GLINE; }
    break;

  case 183:
#line 711 "./ircd_parser.y"
    { (yyval.num) = PRIV_LIST_CHAN; }
    break;

  case 184:
#line 712 "./ircd_parser.y"
    { (yyval.num) = PRIV_PROPAGATE; invert = 1; }
    break;

  case 185:
#line 713 "./ircd_parser.y"
    { (yyval.num) = PRIV_FORCE_OPMODE; }
    break;

  case 186:
#line 714 "./ircd_parser.y"
    { (yyval.num) = PRIV_FORCE_LOCAL_OPMODE; }
    break;

  case 187:
#line 715 "./ircd_parser.y"
    { (yyval.num) = PRIV_NOAMSG_OVERRIDE; }
    break;

  case 188:
#line 716 "./ircd_parser.y"
    { (yyval.num) = PRIV_APASS_OPMODE; }
    break;

  case 189:
#line 718 "./ircd_parser.y"
    { (yyval.num) = 1; }
    break;

  case 190:
#line 718 "./ircd_parser.y"
    { (yyval.num) = 0; }
    break;

  case 191:
#line 724 "./ircd_parser.y"
    { (yyval.num) = 0; }
    break;

  case 192:
#line 725 "./ircd_parser.y"
    { (yyval.num) = USE_IPV4; }
    break;

  case 193:
#line 726 "./ircd_parser.y"
    { (yyval.num) = USE_IPV6; }
    break;

  case 194:
#line 727 "./ircd_parser.y"
    { (yyval.num) = USE_IPV4 | USE_IPV6; }
    break;

  case 195:
#line 728 "./ircd_parser.y"
    { (yyval.num) = USE_IPV6 | USE_IPV4; }
    break;

  case 196:
#line 732 "./ircd_parser.y"
    {
  struct ListenerFlags flags_here;
  struct SLink *link;
  if (hosts == NULL) {
    struct SLink *link;
    link = make_link();
    DupString(link->value.cp, "*");
    link->flags = 0;
    link->next = hosts;
    hosts = link;
  }
  for (link = hosts; link != NULL; link = link->next) {
    memcpy(&flags_here, &listen_flags, sizeof(&flags_here));
    switch (link->flags & (USE_IPV4 | USE_IPV6)) {
    case USE_IPV4:
      FlagSet(&flags_here, LISTEN_IPV4);
      break;
    case USE_IPV6:
      FlagSet(&flags_here, LISTEN_IPV6);
      break;
    default: /* 0 or USE_IPV4|USE_IPV6 */
      FlagSet(&flags_here, LISTEN_IPV4);
      FlagSet(&flags_here, LISTEN_IPV6);
      break;
    }
    if (link->flags & 65535)
      port = link->flags & 65535;
    add_listener(port, link->value.cp, pass, &flags_here);
  }
  free_slist(&hosts);
  MyFree(pass);
  memset(&listen_flags, 0, sizeof(listen_flags));
  pass = NULL;
  port = 0;
}
    break;

  case 206:
#line 770 "./ircd_parser.y"
    {
  if ((yyvsp[(4) - (5)].num) < 1 || (yyvsp[(4) - (5)].num) > 65535) {
    parse_error("Port %d is out of range", port);
  } else {
    port = (yyvsp[(3) - (5)].num) | (yyvsp[(4) - (5)].num);
    if (hosts && (0 == (hosts->flags & 65535)))
      hosts->flags = (hosts->flags & ~65535) | port;
  }
}
    break;

  case 207:
#line 781 "./ircd_parser.y"
    {
  struct SLink *link;
  link = make_link();
  link->value.cp = (yyvsp[(4) - (5)].text);
  link->flags = (yyvsp[(3) - (5)].num) | port;
  link->next = hosts;
  hosts = link;
}
    break;

  case 208:
#line 791 "./ircd_parser.y"
    {
  if ((yyvsp[(5) - (6)].num) < 1 || (yyvsp[(5) - (6)].num) > 65535) {
    parse_error("Port %d is out of range", port);
  } else {
    struct SLink *link;
    link = make_link();
    link->value.cp = (yyvsp[(4) - (6)].text);
    link->flags = (yyvsp[(3) - (6)].num) | (yyvsp[(5) - (6)].num);
    link->next = hosts;
    hosts = link;
  }
}
    break;

  case 209:
#line 805 "./ircd_parser.y"
    {
  MyFree(pass);
  pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 210:
#line 811 "./ircd_parser.y"
    {
  FlagSet(&listen_flags, LISTEN_SERVER);
}
    break;

  case 211:
#line 814 "./ircd_parser.y"
    {
  FlagClr(&listen_flags, LISTEN_SERVER);
}
    break;

  case 212:
#line 819 "./ircd_parser.y"
    {
  FlagSet(&listen_flags, LISTEN_HIDDEN);
}
    break;

  case 213:
#line 822 "./ircd_parser.y"
    {
  FlagClr(&listen_flags, LISTEN_HIDDEN);
}
    break;

  case 214:
#line 827 "./ircd_parser.y"
    {
  FlagSet(&listen_flags, LISTEN_SSL);
}
    break;

  case 215:
#line 830 "./ircd_parser.y"
    {
  FlagClr(&listen_flags, LISTEN_SSL);
}
    break;

  case 216:
#line 835 "./ircd_parser.y"
    {
  maxlinks = 65535;
  port = 0;
}
    break;

  case 217:
#line 840 "./ircd_parser.y"
    {
  struct ConfItem *aconf = 0;
  struct irc_in_addr addr;
  unsigned char addrbits = 0;

  if (!c_class)
    parse_error("Invalid or missing class in Client block");
  else if (pass && strlen(pass) > PASSWDLEN)
    parse_error("Password too long in connect block");
  else if (ip && !ipmask_parse(ip, &addr, &addrbits))
    parse_error("Invalid IP address %s in Client block", ip);
  else {
    aconf = make_conf(CONF_CLIENT);
    aconf->username = username;
    aconf->host = host;
    if (ip)
      memcpy(&aconf->address.addr, &addr, sizeof(aconf->address.addr));
    else
      memset(&aconf->address.addr, 0, sizeof(aconf->address.addr));
    aconf->address.port = port;
    aconf->addrbits = addrbits;
    aconf->name = ip;
    aconf->conn_class = c_class;
    aconf->maximum = maxlinks;
    aconf->passwd = pass;
  }
  if (!aconf) {
    MyFree(username);
    MyFree(host);
    MyFree(ip);
    MyFree(pass);
  }
  host = NULL;
  username = NULL;
  c_class = NULL;
  maxlinks = 0;
  ip = NULL;
  pass = NULL;
  port = 0;
}
    break;

  case 227:
#line 883 "./ircd_parser.y"
    {
  char *sep = strchr((yyvsp[(3) - (4)].text), '@');
  MyFree(host);
  if (sep) {
    *sep++ = '\0';
    MyFree(username);
    DupString(host, sep);
    username = (yyvsp[(3) - (4)].text);
  } else {
    host = (yyvsp[(3) - (4)].text);
  }
}
    break;

  case 228:
#line 896 "./ircd_parser.y"
    {
  char *sep;
  sep = strchr((yyvsp[(3) - (4)].text), '@');
  MyFree(ip);
  if (sep) {
    *sep++ = '\0';
    MyFree(username);
    DupString(ip, sep);
    username = (yyvsp[(3) - (4)].text);
  } else {
    ip = (yyvsp[(3) - (4)].text);
  }
}
    break;

  case 229:
#line 910 "./ircd_parser.y"
    {
  MyFree(username);
  username = (yyvsp[(3) - (4)].text);
}
    break;

  case 230:
#line 915 "./ircd_parser.y"
    {
  c_class = find_class((yyvsp[(3) - (4)].text));
  if (!c_class)
    parse_error("No such connection class '%s' for Client block", (yyvsp[(3) - (4)].text));
  MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 231:
#line 922 "./ircd_parser.y"
    {
  MyFree(pass);
  pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 232:
#line 927 "./ircd_parser.y"
    {
  maxlinks = (yyvsp[(3) - (4)].num);
}
    break;

  case 233:
#line 931 "./ircd_parser.y"
    {
  port = (yyvsp[(3) - (4)].num);
}
    break;

  case 234:
#line 936 "./ircd_parser.y"
    {
  dconf = (struct DenyConf*) MyCalloc(1, sizeof(*dconf));
}
    break;

  case 235:
#line 939 "./ircd_parser.y"
    {
  if (dconf->usermask || dconf->hostmask ||dconf->realmask) {
    dconf->next = denyConfList;
    denyConfList = dconf;
  }
  else
  {
    MyFree(dconf->usermask);
    MyFree(dconf->hostmask);
    MyFree(dconf->realmask);
    MyFree(dconf->message);
    MyFree(dconf);
    parse_error("Kill block must match on at least one of username, host or realname");
  }
  dconf = NULL;
}
    break;

  case 243:
#line 958 "./ircd_parser.y"
    {
  char *h;
  MyFree(dconf->hostmask);
  MyFree(dconf->usermask);
  if ((h = strchr((yyvsp[(3) - (4)].text), '@')) == NULL)
  {
    DupString(dconf->usermask, "*");
    dconf->hostmask = (yyvsp[(3) - (4)].text);
  }
  else
  {
    *h++ = '\0';
    DupString(dconf->hostmask, h);
    dconf->usermask = (yyvsp[(3) - (4)].text);
  }
  ipmask_parse(dconf->hostmask, &dconf->address, &dconf->bits);
}
    break;

  case 244:
#line 977 "./ircd_parser.y"
    {
  MyFree(dconf->usermask);
  dconf->usermask = (yyvsp[(3) - (4)].text);
}
    break;

  case 245:
#line 983 "./ircd_parser.y"
    {
 MyFree(dconf->realmask);
 dconf->realmask = (yyvsp[(3) - (4)].text);
}
    break;

  case 246:
#line 989 "./ircd_parser.y"
    {
 dconf->flags &= ~DENY_FLAGS_FILE;
 MyFree(dconf->message);
 dconf->message = (yyvsp[(3) - (4)].text);
}
    break;

  case 247:
#line 996 "./ircd_parser.y"
    {
 dconf->flags |= DENY_FLAGS_FILE;
 MyFree(dconf->message);
 dconf->message = (yyvsp[(3) - (4)].text);
}
    break;

  case 248:
#line 1003 "./ircd_parser.y"
    {
  tconn = CRULE_AUTO;
}
    break;

  case 249:
#line 1006 "./ircd_parser.y"
    {
  struct CRuleNode *node = NULL;
  struct SLink *link;

  if (hosts == NULL)
    parse_error("Missing server(s) in crule block");
  else if (pass == NULL)
    parse_error("Missing rule in crule block");
  else if ((node = crule_parse(pass)) == NULL)
    parse_error("Invalid rule '%s' in crule block", pass);
  else for (link = hosts; link != NULL; link = link->next)
  {
    struct CRuleConf *p = (struct CRuleConf*) MyMalloc(sizeof(*p));
    if (node == NULL)
      node = crule_parse(pass);
    DupString(p->hostmask, link->value.cp);
    DupString(p->rule, pass);
    p->type = tconn;
    p->node = node;
    node = NULL;
    p->next = cruleConfList;
    cruleConfList = p;
  }
  free_slist(&hosts);
  MyFree(pass);
  pass = NULL;
  tconn = 0;
}
    break;

  case 255:
#line 1039 "./ircd_parser.y"
    {
  struct SLink *link;
  link = make_link();
  link->value.cp = (yyvsp[(3) - (4)].text);
  link->next = hosts;
  hosts = link;
}
    break;

  case 256:
#line 1048 "./ircd_parser.y"
    {
 MyFree(pass);
 pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 257:
#line 1054 "./ircd_parser.y"
    {
 tconn = CRULE_ALL;
}
    break;

  case 258:
#line 1057 "./ircd_parser.y"
    {
 tconn = CRULE_AUTO;
}
    break;

  case 259:
#line 1062 "./ircd_parser.y"
    {
  struct SLink *link;
  if (pass != NULL)
    for (link = hosts; link != NULL; link = link->next)
      motd_add(link->value.cp, pass);
  free_slist(&hosts);
  MyFree(pass);
  pass = NULL;
}
    break;

  case 264:
#line 1075 "./ircd_parser.y"
    {
  struct SLink *link;
  link = make_link();
  link->value.cp = (yyvsp[(3) - (4)].text);
  link->next = hosts;
  hosts = link;
}
    break;

  case 265:
#line 1084 "./ircd_parser.y"
    {
  MyFree(pass);
  pass = (yyvsp[(3) - (4)].text);
}
    break;

  case 269:
#line 1093 "./ircd_parser.y"
    {
  stringlist[0] = (yyvsp[(1) - (1)].text);
  stringno = 1;
}
    break;

  case 270:
#line 1096 "./ircd_parser.y"
    {
  unsigned int ii;
  feature_set(NULL, (const char * const *)stringlist, stringno);
  for (ii = 0; ii < stringno; ++ii)
    MyFree(stringlist[ii]);
}
    break;

  case 273:
#line 1105 "./ircd_parser.y"
    {
  if (stringno < MAX_STRINGS)
    stringlist[stringno++] = (yyvsp[(1) - (1)].text);
  else
    MyFree((yyvsp[(1) - (1)].text));
}
    break;

  case 277:
#line 1115 "./ircd_parser.y"
    {
  struct qline *qconf = MyCalloc(1, sizeof(*qconf));
  qconf->chname = (yyvsp[(1) - (4)].text);
  qconf->reason = (yyvsp[(3) - (4)].text);
  qconf->next = GlobalQuarantineList;
  GlobalQuarantineList = qconf;
}
    break;

  case 278:
#line 1124 "./ircd_parser.y"
    {
  smap = MyCalloc(1, sizeof(struct s_map));
  smap->command = (yyvsp[(2) - (3)].text);
}
    break;

  case 279:
#line 1129 "./ircd_parser.y"
    {
  int valid = 0;

  if (!smap->name)
    parse_error("Missing name in pseudo %s block", smap->command);
  else if (!smap->services)
    parse_error("Missing nick in pseudo %s block", smap->command);
  else if (!strIsAlpha(smap->command))
    parse_error("Pseudo command %s invalid: must all be letters", smap->command);
  else
    valid = 1;
  if (valid && register_mapping(smap))
  {
    smap->next = GlobalServiceMapList;
    GlobalServiceMapList = smap;
  }
  else
  {
    free_mapping(smap);
  }
  smap = NULL;
}
    break;

  case 286:
#line 1155 "./ircd_parser.y"
    {
  MyFree(smap->name);
  smap->name = (yyvsp[(3) - (4)].text);
}
    break;

  case 287:
#line 1160 "./ircd_parser.y"
    {
  MyFree(smap->prepend);
  smap->prepend = (yyvsp[(3) - (4)].text);
}
    break;

  case 288:
#line 1165 "./ircd_parser.y"
    {
  char *sep = strchr((yyvsp[(3) - (4)].text), '@');

  if (sep != NULL) {
    size_t slen = strlen((yyvsp[(3) - (4)].text));
    struct nick_host *nh = MyMalloc(sizeof(*nh) + slen);
    memcpy(nh->nick, (yyvsp[(3) - (4)].text), slen + 1);
    nh->nicklen = sep - (yyvsp[(3) - (4)].text);
    nh->next = smap->services;
    smap->services = nh;
  }
  MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 289:
#line 1179 "./ircd_parser.y"
    {
  smap->flags |= SMAP_FAST;
}
    break;

  case 290:
#line 1184 "./ircd_parser.y"
    {
  auth_spawn(stringno, stringlist, iauth_required);
  while (stringno > 0)
  {
    --stringno;
    MyFree(stringlist[stringno]);
  }
  iauth_required = 0;
}
    break;

  case 295:
#line 1197 "./ircd_parser.y"
    {
  while (stringno > 0)
  {
    --stringno;
    MyFree(stringlist[stringno]);
  }
}
    break;

  case 297:
#line 1206 "./ircd_parser.y"
    {
  iauth_required = (yyvsp[(3) - (4)].num);
}
    break;

  case 298:
#line 1210 "./ircd_parser.y"
    {
  unsigned int ii;
  for(ii = 0; ii < 256; ++ii) {
    MyFree(GlobalForwards[ii]);
  }
}
    break;

  case 302:
#line 1218 "./ircd_parser.y"
    {
  unsigned char ch = (yyvsp[(1) - (4)].text)[0];
  MyFree(GlobalForwards[ch]);
  GlobalForwards[ch] = (yyvsp[(3) - (4)].text);
  MyFree((yyvsp[(1) - (4)].text));
}
    break;

  case 303:
#line 1225 "./ircd_parser.y"
    {
    /* If we read a new webirc block, we create a new block. */
    webirc = webirc_block();
}
    break;

  case 304:
#line 1228 "./ircd_parser.y"
    {
    /* check for integrity */
    if(!webirc->name[0]) {
        parse_error("Every WebIRC block needs at least a name entry.");
        webirc_list_clear(webirc);
        MyFree(webirc);
        webirc = NULL;
    }
    else {
        webirc_establish(webirc);
        webirc = NULL;
    }
}
    break;

  case 313:
#line 1243 "./ircd_parser.y"
    {
    unsigned int len;
    if((len = strlen((yyvsp[(3) - (4)].text))) > 0)
        webirc_set(webirc, WEBIRC_PASS, (yyvsp[(3) - (4)].text), len, 0);
    MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 314:
#line 1249 "./ircd_parser.y"
    {
    unsigned int len;
    if((len = strlen((yyvsp[(3) - (4)].text))) > 0)
        webirc_set(webirc, WEBIRC_HOST, (yyvsp[(3) - (4)].text), len, 0);
    MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 315:
#line 1255 "./ircd_parser.y"
    {
    unsigned int len;
    if((len = strlen((yyvsp[(4) - (5)].text))) > 0)
        webirc_set(webirc, WEBIRC_HOST, (yyvsp[(4) - (5)].text), len, 1);
    MyFree((yyvsp[(4) - (5)].text));
}
    break;

  case 316:
#line 1261 "./ircd_parser.y"
    {
    unsigned int len;
    if((len = strlen((yyvsp[(3) - (4)].text))) > 0)
        webirc_set(webirc, WEBIRC_SPOOF, (yyvsp[(3) - (4)].text), len, 0);
    MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 317:
#line 1267 "./ircd_parser.y"
    {
    unsigned int len;
    if((len = strlen((yyvsp[(4) - (5)].text))) > 0)
        webirc_set(webirc, WEBIRC_SPOOF, (yyvsp[(4) - (5)].text), len, 1);
    MyFree((yyvsp[(4) - (5)].text));
}
    break;

  case 318:
#line 1273 "./ircd_parser.y"
    {
    unsigned int len;
    if(webirc->name[0]) {
        MyFree((yyvsp[(3) - (4)].text));
        parse_error("Only one name entry per WebIRC is allowed.");
    }
    else if((len = strlen((yyvsp[(3) - (4)].text))) > NICKLEN) {
        MyFree((yyvsp[(3) - (4)].text));
        parse_error("WebIRC block name length is limited to NICKLEN.");
    }
    else {
        if((len = strlen((yyvsp[(3) - (4)].text))) > 0) {
            strcpy(webirc->name, (yyvsp[(3) - (4)].text));
            webirc->name[len] = '\0';
        }
        MyFree((yyvsp[(3) - (4)].text));
    }
}
    break;

  case 324:
#line 1295 "./ircd_parser.y"
    {
    ssl_setcert((yyvsp[(3) - (4)].text));
    MyFree((yyvsp[(3) - (4)].text));
}
    break;

  case 325:
#line 1299 "./ircd_parser.y"
    {
    ssl_addtrust((yyvsp[(3) - (4)].text));
    MyFree((yyvsp[(3) - (4)].text));
}
    break;


/* Line 1267 of yacc.c.  */
#line 3893 "y.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



