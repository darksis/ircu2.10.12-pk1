/*
 * version.h
 *
 * $Id: version.h 27 2000-03-18 05:20:30Z bleep $
 */
#ifndef INCLUDED_version_h
#define INCLUDED_version_h

extern const char *version;
extern const char *creation;
extern const char *infotext[];
extern const char *generation;
extern const char *svn_srev;

#endif /* INCLUDED_version_h */
