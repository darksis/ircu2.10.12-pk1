/*
 * Written by David Herrmann.
 * Dedicated to the Public Domain.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#include <unistd.h>

#include "iauth.h"

/* /path/to/logfile.log or NULL. */
const char *iauth_logfile = NULL;
/* Current logfile or NULL. */
FILE *logfile = NULL;
/* 1 if debug mode is enabled, otherwise 0. */
unsigned int iauth_debug = 0;

static void iauth_error(const char *msg, size_t len) {
    fwrite(msg, 1, len, stderr);
    fwrite("\n", 1, 1, stderr);
    /*abort();*/
    exit(1);
}

void iauth_ferror(const char *format, ...) {
    va_list arg;

    va_start(arg, format);
    iauth_verror(format, arg);
    va_end(arg);
}

void iauth_verror(const char *format, va_list list) {
    char buffer[IAUTH_LINE + 1];
    size_t len;

    memset(buffer, 0, IAUTH_LINE + 1);
    len = vsnprintf(buffer, IAUTH_LINE, format, list);
    if(!len) len = snprintf(buffer, IAUTH_LINE, "<no error message specified>");
    iauth_error(buffer, len);
}

/* Checks whether we need to reopen the logfile.
 * Aborts the application if the logfile cannot be
 * opened.
 */
static void iauth_log_reopen() {
    if(iauth_logfile) {
        if(logfile) fclose(logfile);
        logfile = fopen(iauth_logfile, "a");
        if(!logfile) iauth_ferror("Logfile '%s' could not be opened in mode 'a'; errno = '%d'.", iauth_logfile, errno);
        iauth_logfile = NULL;
    }
    else if(!logfile) iauth_ferror("No logfile specified.");
}

static void iauth_log(unsigned int type, const char *msg, size_t len) {
    struct tm *tstamp;
    time_t curtime;
    char buffer[IAUTH_LINE + 1];
    size_t len2;

    iauth_log_reopen();

    curtime = time(NULL);
    tstamp = localtime(&curtime);
    memset(buffer, 0, IAUTH_LINE + 1);
    len2 = snprintf(buffer, IAUTH_LINE + 1, "[%02d.%02d.%d %02d:%02d:%02d]", tstamp->tm_mday, tstamp->tm_mon + 1, tstamp->tm_year + 1900, 
                                                                             tstamp->tm_hour, tstamp->tm_min, tstamp->tm_sec);
    len2 += snprintf(&buffer[len2], IAUTH_LINE + 1 - len2, " (%s): ", (type == IAUTH_FATAL)?"FATAL":(type == IAUTH_WARNING)?"WARNING":
                                                                      (type == IAUTH_INFO)?"INFO":(type == IAUTH_DEBUG)?"DEBUG":"UNKNOWN");

    if(fwrite(buffer, 1, len2, logfile) != len2) iauth_ferror("Write operation on logfile failed; errno = '%d'.", errno);
    if(fwrite(msg, 1, len, logfile) != len) iauth_ferror("Write operation on logfile failed; errno = '%d'.", errno);
    fwrite("\n", 1, 1, logfile);
    fflush(logfile);
}

void iauth_flog(unsigned int type, const char *format, ...) {
    va_list arg;

    va_start(arg, format);
    iauth_vlog(type, format, arg);
    va_end(arg);
}

void iauth_vlog(unsigned int type, const char *format, va_list list) {
    char buffer[IAUTH_LINE + 1];
    size_t len;

    memset(buffer, 0, IAUTH_LINE + 1);
    len = vsnprintf(buffer, IAUTH_LINE, format, list);
    if(!len) len = snprintf(buffer, IAUTH_LINE, "<no message specified>");
    iauth_log(type, buffer, len);
}

void iauth_eflog(const char *format, ...) {
    va_list arg;

    va_start(arg, format);
    iauth_evlog(format, arg);
    va_end(arg);
}

void iauth_evlog(const char *format, va_list list) {
    char buffer[IAUTH_LINE + 1];
    size_t len;

    memset(buffer, 0, IAUTH_LINE + 1);
    len = vsnprintf(buffer, IAUTH_LINE, format, list);
    if(!len) len = snprintf(buffer, IAUTH_LINE, "<no message specified>");
    iauth_log(IAUTH_FATAL, buffer, len);
    iauth_error(buffer, len);
}

char *iauth_read() {
    static char buffer[IAUTH_LINE + 1];
    unsigned int i, ignore = 0;

    next_line:

    if(!fgets(buffer, IAUTH_LINE, stdin)) {
        if(feof(stdin)) return NULL;
        iauth_eflog("Reading on stdin failed; errno = '%d'.", errno);
    }
    buffer[IAUTH_LINE] = 0;

    for(i = 0; i < IAUTH_LINE; ++i) {
        if(buffer[i] == '\n') {
            if(ignore) {
                ignore = 0;
                goto next_line;
            }
            if(i == 0) goto next_line;
            if(buffer[i - 1] == '\r') {
                if(i == 1) goto next_line;
                buffer[i - 1] = 0;
            }
            else buffer[i] = 0;
            if(iauth_debug) {
                iauth_flog(IAUTH_DEBUG, "IN -> %s", buffer);
            }
            return buffer;
        }
    }

    /* Too long message. Discard it! */
    iauth_flog(IAUTH_WARNING, "Message exceeded maximum length of '%d' bytes.", IAUTH_LINE);
    ignore = 1;
    goto next_line;
}

void iauth_fsend(const char *format, ...) {
    va_list arg;

    va_start(arg, format);
    iauth_vsend(format, arg);
    va_end(arg);
}

void iauth_vsend(const char *format, va_list list) {
    char buffer[IAUTH_LINE + 1];
    size_t len, len2;

    memset(buffer, 0, IAUTH_LINE + 1);
    if(iauth_debug) {
        len2 = snprintf(buffer, IAUTH_LINE, "OUT <- ");
        len = vsnprintf(&buffer[len2], IAUTH_LINE, format, list);
        if(!len) return;
        iauth_log(IAUTH_DEBUG, buffer, len + len2);
        if(write(0, &buffer[len2], len) != len) iauth_eflog("IAuth write operation failed; errno = '%d'", errno);
        write(0, "\r\n", 2);
    }
    else {
        len = vsnprintf(buffer, IAUTH_LINE, format, list);
        if(!len) return;
        if(write(0, buffer, len) != len) iauth_eflog("IAuth write operation failed; errno = '%d'", errno);
        write(0, "\r\n", 2);
    }
}
