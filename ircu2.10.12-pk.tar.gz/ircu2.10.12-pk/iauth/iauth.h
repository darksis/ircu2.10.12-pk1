/*
 * Written by David Herrmann.
 * Dedicated to the Public Domain.
 */

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

/* Global configuration.
 * It is not recommended to change these values. They are set to
 * an especially high value to support even the weirdest environments.
 */
/* Maximal length of a line. */
#define IAUTH_LINE 4096
/* Maximal capacity. */
#define IAUTH_CAPMAX 1000000
/* Maximum length of accounts/classes/fakehosts etc.. */
#define IAUTH_DATALEN 256

/* 1 if debug mode is enabled, otherwise 0. */
extern unsigned int iauth_debug;

/* Log functions.
 * These functions write status data into a log file.
 * They all do the same but take either a formatted argument
 * or a va_list buffer.
 * Error functions log the message and terminate the application,
 * log functions only log the message.
 */
#define IAUTH_FATAL 0
#define IAUTH_WARNING 1
#define IAUTH_INFO 2
#define IAUTH_DEBUG 3
extern const char *iauth_logfile;
extern void iauth_ferror(const char *format, ...);
extern void iauth_verror(const char *format, va_list list);
extern void iauth_flog(unsigned int type, const char *format, ...);
extern void iauth_vlog(unsigned int type, const char *format, va_list list);
extern void iauth_eflog(const char *format, ...);
extern void iauth_evlog(const char *format, va_list list);

/* IO functions.
 * These functions either write a line to the IAuth or read a
 * single line from the IAuth.
 */
extern char *iauth_read();
extern void iauth_fsend(const char *format, ...);
extern void iauth_vsend(const char *format, va_list list);

/* Allocates/frees memory.
 * Aborts with an appropriate message if the allocation fails.
 */
static inline void *iauth_malloc(size_t size) {
    void *mem;
    if(!(mem = malloc(size))) iauth_eflog("Memory allocation failed.");
    memset(mem, 0, size);
    return mem;
}
static inline char *iauth_strdup(const char *str) {
    char *mem;
    if(!(mem = strdup(str))) iauth_eflog("strdup() failed.");
    return mem;
}
#define iauth_free(x) ((void)((x)?free(x):0))

/* User management.
 * Adds or removes a user.
 */
struct iauth_client {
    signed int id;
    char *ip;
    unsigned short port;
    char *lo_ip;
    unsigned short lo_port;
    char *host;
    char *c_host;
    char *c_serv;
    char *nick;
    char *username;
    char *realname;
    char *account;
    char *fakehost;
    char *cclass;
    char *password;
    char *ident;
    unsigned int state_r : 1; /* Is in "registering" state. */
    unsigned int state_h : 1; /* Is in "hurry" state. */
};
#define iauth_set(x, y) (iauth_free(x), (x = y))
extern struct iauth_client *iauth_clients;
extern unsigned int iauth_clients_size;
extern void iauth_setcap(unsigned int cap);
extern void iauth_addid(signed int id);
extern void iauth_delid(signed int id);

/* Request handler.
 * The real requests are outsourced to a scriptfile.
 * The iauth process spawns the scriptfile, passes the
 * data as arguments and exspects the process to return
 * the result on stdout.
 * The scriptfile is spawned for every request.
 */
extern char *iauth_scriptfile;
struct iauth_result {
    char cclass[IAUTH_DATALEN + 1];
    char ident[IAUTH_DATALEN + 1];
    char host[IAUTH_DATALEN + 1];
    char ip[IAUTH_DATALEN + 1];
    char modes[IAUTH_DATALEN + 1];
    char str[600];
};
extern const struct iauth_result *iauth_query(struct iauth_client *cli);
extern char iauth_servname[IAUTH_DATALEN + 1];

/* Sends a specific request to the ircd.
 * This is a less generic but easier to use interface
 * for the iauth_[vf]send() commands. This interface also
 * correctly sends statistics.
 */

/* Operator Notification: > :<message text> */
extern void iauth_query_fnotify(const char *format, ...);
extern void iauth_query_vnotify(const char *format, va_list list);
/* Set Debug Level: G <level> */
extern void iauth_query_debug(unsigned int debuglevel);
/* Set Policy Options: O <options> */
extern void iauth_query_policy(const char *policy);
/* iauth Program Version: V :<version string> */
extern void iauth_query_version(const char *version);
/* Start of new configuration: a */
extern void iauth_query_newconf();
/* Configuration Information: A <hosts?> <module> :<options> */
extern void iauth_query_config(const char *hosts, const char *module, const char *value);
/* Start of new statistics: s */
extern void iauth_query_newstats();
/* Statistics Information: S <module> :<module information> */
extern void iauth_query_stats(const char *module, const char *value);
/* Forced Username: o <id> <remoteip> <remoteport> <username> */
extern void iauth_query_set_username(signed int id, const char *username);
/* Trusted Username: U <id> <remoteip> <remoteport> <username> */
extern void iauth_query_trust_username(signed int id, const char *username);
/* Untrusted Username: u <id> <remoteip> <remoteport> <username> */
extern void iauth_query_distrust_username(signed int id, const char *username);
/* Client Hostname: N <id> <remoteip> <remoteport> <hostname> */
extern void iauth_query_sethost(signed int id, const char *hostname);
/* Client IP Address: I <id> <currentip> <remoteport> <newip> */
extern void iauth_query_setip(signed int id, const char *ip);
/* Adjust User Mode: M <id> <remoteip> <remoteport> +<mode changes> */
extern void iauth_query_setmodes(signed int id, const char *modes);
/* Challenge User: C <id> <remoteip> <remoteport> :<challenge string> */
extern void iauth_query_challenge(signed int id, const char *challenge);
/* Quietly Kill Client: k <id> <remoteip> <remoteport> :<reason> */
extern void iauth_query_reject(signed int id, const char *reason);
/* Kill Client: K <id> <remoteip> <remoteport> :<reason> */
extern void iauth_query_kill(signed int id, const char *reason);
/* Done Checking: D <id> <remoteip> <remoteport> [class] */
extern void iauth_query_assign(signed int id, const char *cclass);
/* Registered User: R <id> <remoteip> <remoteport> <account> [class] */
extern void iauth_query_register(signed int id, const char *account, const char *cclass);

/* Subcommand handlers. */
extern void iauth_cmd_C(signed int id, char *arg);
extern void iauth_cmd_D(struct iauth_client *client);
extern void iauth_cmd_L(struct iauth_client *client, char *arg);
extern void iauth_cmd_H(struct iauth_client *client, char *arg);
extern void iauth_cmd_M(char *arg);
extern void iauth_cmd_N(struct iauth_client *client, char *arg);
extern void iauth_cmd_d(struct iauth_client *client);
extern void iauth_cmd_P(struct iauth_client *client, char *arg);
extern void iauth_cmd_U(struct iauth_client *client, char *arg);
extern void iauth_cmd_u(struct iauth_client *client, char *arg);
extern void iauth_cmd_n(struct iauth_client *client, char *arg);
extern void iauth_cmd_T(struct iauth_client *client);
extern void iauth_cmd_E(signed int id, char *arg);

/* Statistics */
extern void iauth_stats_report();
extern void iauth_stats_loc_allow();
extern void iauth_stats_loc_deny();
extern void iauth_stats_def_allow();
extern void iauth_stats_def_deny();

