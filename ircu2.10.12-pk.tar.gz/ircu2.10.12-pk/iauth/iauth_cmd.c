/*
 * Written by David Herrmann.
 * Dedicated to the Public Domain.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include "iauth.h"

char iauth_servname[IAUTH_DATALEN + 1];

static char *iauth_next_data(char **arg) {
    char *sep, *ret;
    unsigned int len;

    while(**arg == ' ') ++*arg;
    if(!**arg) return NULL;
    if(**arg == ':' || !(sep = strchr(*arg, ' '))) {
        if(**arg == ':') ++*arg;
        len = strlen(*arg);
        ret = iauth_malloc(len + 1);
        strcpy(ret, *arg);
        *arg += len;
        if(len > IAUTH_DATALEN) ret[IAUTH_DATALEN] = 0;
        else ret[len] = 0;
        return ret;
    }
    else {
        *sep = 0;
        len = strlen(*arg);
        ret = iauth_malloc(len + 1);
        strcpy(ret, *arg);
        if(len > IAUTH_DATALEN) ret[IAUTH_DATALEN] = 0;
        else ret[len] = 0;
        *sep = ' ';
        *arg = sep + 1;
        return ret;
    }
}

/* Client Introduction: <id> C <remoteip> <remoteport> <localip> <localport> */
void iauth_cmd_C(signed int id, char *arg) {
    char *str;
    struct iauth_client *cli;

    iauth_delid(id);
    iauth_addid(id);
    cli = &iauth_clients[id];

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(cli->ip, str);

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    cli->port = atoi(str);
    iauth_free(str);

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(cli->lo_ip, str);

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    cli->lo_port = atoi(str);
    iauth_free(str);

    iauth_flog(IAUTH_INFO, "New client (%d) from '%s':%hu to '%s':%hu.", id, cli->ip, cli->port, cli->lo_ip, cli->lo_port);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid C line.");
    iauth_delid(id);
    return;
}

/* Client Disconnect: <id> D */
void iauth_cmd_D(struct iauth_client *client) {
    iauth_delid(client->id);
}

/* Login On Connect: <id> L <account>[:<accountstamp>][ <fakehost>] */
void iauth_cmd_L(struct iauth_client *client, char *arg) {
    char *str;
    const struct iauth_result *res;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->account, str);

    str = iauth_next_data(&arg);
    if(str) iauth_set(client->fakehost, str);

    /* Query database for account query. */
    res = iauth_query(client);
    if(!res) {
        iauth_query_reject(client->id, "Access denied.");
        iauth_stats_loc_deny();
    }
    else {
     if(strcmp(res->cclass, "error") == 0) {
	    iauth_query_reject(client->id, res->str);
        iauth_stats_loc_deny();
	 } else {
        if(*res->ident) iauth_query_set_username(client->id, res->ident);
        if(*res->host) iauth_query_sethost(client->id, res->host);
        if(*res->ip) iauth_query_setip(client->id, res->ip);
        if(*res->modes) iauth_query_setmodes(client->id, res->modes);
        iauth_query_assign(client->id, (*res->cclass)?res->cclass:NULL);
        iauth_stats_loc_allow();
     }
    }

    iauth_delid(client->id);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid L line.");
    return;
}

/* Hurry Up: <id> H <class> */
void iauth_cmd_H(struct iauth_client *client, char *arg) {
    char *str;
    const struct iauth_result *res;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->cclass, str);
    client->state_h = 1;

    /* Query database for account query. */
    res = iauth_query(client);
    if(!res) {
        iauth_query_reject(client->id, "Access denied.");
        iauth_stats_def_deny();
    }
    else {
     if(strcmp(res->cclass, "error") == 0) {
	    iauth_query_reject(client->id, res->str);
        iauth_stats_loc_deny();
	 } else {
        if(*res->ident) iauth_query_set_username(client->id, res->ident);
        if(*res->host) iauth_query_sethost(client->id, res->host);
        if(*res->ip) iauth_query_setip(client->id, res->ip);
        if(*res->modes) iauth_query_setmodes(client->id, res->modes);
        iauth_query_assign(client->id, (*res->cclass)?res->cclass:NULL);
        iauth_stats_def_allow();
     }
    }
    iauth_delid(client->id);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid H line.");
    return;
}

/* Server Name and Capacity: <id> M <servername> <capacity> */
void iauth_cmd_M(char *arg) {
    char *server = NULL, *str = NULL;
    unsigned int cap;

    server = iauth_next_data(&arg);
    if(!server) goto parse_error;

    str = iauth_next_data(&arg);
    if(!str || !*str || (cap = atoi(str)) == 0) goto parse_error;
    iauth_setcap(cap);
    iauth_flog(IAUTH_INFO, "Setting server (%s) capacity to: %u.", server, cap);
    strcpy(iauth_servname, server);
    iauth_free(str);
    iauth_free(server);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid M line.");
    iauth_free(server);
    iauth_free(str);
    return;
}

/* Hostname Received: <id> N <hostname> */
void iauth_cmd_N(struct iauth_client *client, char *arg) {
    char *str;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->host, str);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid N line.");
    return;
}

/* Hostname Timeout: <id> d */
void iauth_cmd_d(struct iauth_client *client) {
    char *str;

    str = iauth_malloc(1);
    iauth_set(client->host, str);

    return;
}

/* Client Password: <id> P :<password ...> */
void iauth_cmd_P(struct iauth_client *client, char *arg) {
    char *str;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->password, str);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid P line.");
    return;
}

/* Client Username: <id> U <username> <hostname> <servername> :<userinfo ...> */
void iauth_cmd_U(struct iauth_client *client, char *arg) {
    char *str;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->username, str);

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->c_host, str);

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->c_serv, str);

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->realname, str);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid U line.");
    return;
}

/* Client Username: <id> u <username> */
void iauth_cmd_u(struct iauth_client *client, char *arg) {
    char *str;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->ident, str);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid u line.");
    return;
}

/* Client Nickname: <id> n <nickname> */
void iauth_cmd_n(struct iauth_client *client, char *arg) {
    char *str;

    str = iauth_next_data(&arg);
    if(!str) goto parse_error;
    iauth_set(client->nick, str);

    return;
    parse_error:
    iauth_flog(IAUTH_WARNING, "Parse error: Invalid n line.");
    return;
}

/* Client Registered: <id> T */
void iauth_cmd_T(struct iauth_client *client) {
    iauth_flog(IAUTH_INFO, "Client %d was registered without IAuth answer.", client->id);
    iauth_delid(client->id);
}

/* Error: <id> E <type> :<additional text> */
void iauth_cmd_E(signed int id, char *arg) {
    iauth_flog(IAUTH_WARNING, "Received IRCd error: %s", arg);
}

