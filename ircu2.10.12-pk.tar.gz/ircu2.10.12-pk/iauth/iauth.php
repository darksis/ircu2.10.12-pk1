#!/usr/bin/php
<?php
/* Written by David Herrmann,
 *  improved by Philipp Kreil.
 * Dedicated to the Public Domain.
 */
/* PHP IAuth verifier.
 * The IAuth collects all information from the ircd and when it thinks it has a complete
 * set of information, it starts this script with all information as parameters. This
 * script has to check the database for a dataset and return the values it wants to change
 * or return nothing if it wants to reject the client.
 *
 * The data from the IAuth is passed in the array $argv. If a value is not available, it is
 * an empty string. If a value is available it must be a string between 1 and IAUTH_DATALEN
 * characters, whereas IAUTH_DATALEN is defined in iauth.h.
 *  - Name of the script:
 *     $argv[0] = ./iauth.php
 *  - The IP of the remote socket endpoint:
 *     $argv[1] = 85.214.49.253
 *  - The port of the remote socket endpoint:
 *     $argv[2] = 8080
 *  - The ip of the local socket endpoint:
 *     $argv[3] = 127.0.0.1
 *  - The port of the local socket endpoint:
 *     $argv[4] = 6661
 *  - The resolved hostname of the remote socket:
 *     $argv[5] = p3EE37393.dip.t-dialin.net
 *  - The hostname the user passed to USER:
 *     $argv[6] = localhost
 *  - The servername the user passed to USER:
 *     $argv[7] = irc.mIRCxNet.ISRAEL
 *  - The nick which the user passed:
 *     $argv[8] = some_weird_nick
 *  - The username the user passed to USER:
 *     $argv[9] = username
 *  - The realname the user passed to USER:
 *     $argv[10] = realname
 *  - The account[:timestamp] which was proofed by LOC: (The :timestamp is optional)
 *     $argv[11] = some_account:124206424
 *  - The fakehost which was set by LOC:
 *     $argv[12] = cool.1337.fakehost
 *  - The class that the server would assign to the user if iauth would not be there:
 *     $argv[13] = some_server_class
 *  - The last PASS line the user sent:
 *     $argv[14] = some_password
 *  - The ident we got from the user's ident server:
 *     $argv[15] = ident
 *  - The name of the server we are connected to:
 *     $argv[16] = devnull.xy.net
 *
 * The response of the script is sent to STDOUT. If the script wants to reject the request, it can
 * simply exit without sending anything.
 * If you want to accept the client, you have to pass several parameters to STDOUT. Each parameter
 * is separated by a space. If you want to skip a parameter, simply put "$" in there.
 * Every value which is not "$" is forced on the user before he gets assigned to a class.
 * Each value is limited again to IAUTH_DATALEN, however, the ircd itself may limit the data again,
 * therefore, it is recommended to use short values. '\0' characters are not allowed in a reply and
 * the IAuth parser will reject the query.
 * The values are:
 *  - The class which is assigned to the user:
 *     echo "some_class ";
 *  - The ident which should be forced on the user:
 *     echo "FORCEIDENT ";
 *  - The host which should be forced on the user:
 *     echo "forced.host.on.user ";
 *  - The ip which should be forced on the user:
 *     echo "127.244.12.110 ";
 *  - A mode striing which is set on the user. This can include fakehosts/accounts/operators/etc.
 *     echo "+wogsfr 131071 fake.host.net account:124653295"
 * The last parameter "mode" can have as many spaces as you want.
 */
error_reporting(0);
 
/* These constants are defined to access $argv more easily. */
define("ARG_REMOTEIP", $argv[1]);
define("ARG_REMOTEPORT", $argv[2]);
define("ARG_LOCALIP", $argv[3]);
define("ARG_LOCALPORT", $argv[4]);
define("ARG_HOSTNAME", $argv[5]);
define("ARG_USER_HOST", $argv[6]);
define("ARG_USER_SERV", $argv[7]);
define("ARG_NICK", $argv[8]);
define("ARG_USERNAME", $argv[9]);
define("ARG_REALNAME", $argv[10]);
define("ARG_TS_ACCOUNT", $argv[11]);
define("ARG_ACCOUNT", preg_replace('/^(.*?)(:\d+)?$/', '$1', $argv[11]));
define("ARG_FAKEHOST", $argv[12]);
define("ARG_CLASS", $argv[13]);
define("ARG_PASS", $argv[14]);
define("ARG_IDENT", $argv[15]);
define("ARG_SERVER", $argv[16]);

/* This function can be used to return a result. */
function iauth_return($class = NULL, $ident = NULL, $host = NULL, $ip = NULL, $mode = NULL) {
    $class = trim($class);
    $ident = trim($ident);
    $host = trim($host);
    $ip = trim((substr($ip, 0, 1) == ":") ? "0".$ip : $ip);
    $mode = trim($mode);
    if($class === NULL || strlen($class) == 0) $class = "$";
    if($ident === NULL || strlen($ident) == 0) $ident = "$";
    if($host === NULL || strlen($host) == 0) $host = "$";
    if($ip === NULL || strlen($ip) == 0) $ip = "$";
    if($mode === NULL || strlen($mode) == 0) $mode = "$";
    echo "$class $ident $host $ip $mode %";
    exit(0);
}

/* This rejects the client. */
function iauth_reject($reason = NULL) {
    if($reason != NULL && strlen($reason) != 0) echo"error ".$reason." %";
    exit(0);
}

/* Validate the input now and return the right result.
 * REMEMBER: SOME VALUES MIGHT BE AN EMPTY STRING AND NOT SET!
 */


/****************************************************/
/****************************************************/
/* Following three example ways to handle a client. */
/****************************************************/
/****************************************************/

/* Simply allow the client to connect the normal way. */
/* iauth_return(); */

/* Or as an example return only a class and a mode change. */
/* iauth_return("class", NULL, NULL, NULL, "+rf account:14314789 fake.host.net"); */

/* Or reject the client. */
/* iauth_reject(); */

/* our real implementation */
if (is_readable('iauth-mIRCxNet.php')) {
    require('iauth-mIRCxNet.php');
}
iauth_return();

?>
