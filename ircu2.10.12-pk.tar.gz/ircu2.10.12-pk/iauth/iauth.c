/*
 * Written by David Herrmann.
 * Dedicated to the Public Domain.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <signal.h>

#include "iauth.h"

static unsigned int running = 1;

static void iauth_signal(int sig) {
    iauth_flog(IAUTH_INFO, "Caught signal %d, ignoring...", sig);
}

/* Parses one single input line. */
void iauth_parse(char *line) {
    unsigned int i, found;
    signed int id;

    /* The line has to look like:
     * <id> X <several> <arguments>
     */

    found = 0;
    for(i = 0; line[i]; ++i) {
        if(line[i] == ' ') {
            found = 1;
            break;
        }
    }

    /* Ignore invalid lines. */
    if(!found) {
        iauth_flog(IAUTH_WARNING, "Received invalid line; no subcommand specified.");
        return;
    }

    /* Get the id. */
    id = atoi(line);

    /* Ignore invalid subcommands. */
    if(!line[++i] || line[i] == ' ' || (line[i + 1] != ' ' && line[i + 1])) {
        iauth_flog(IAUTH_WARNING, "Received invalid line; invalid subcommand.");
        return;
    }

    /* Call the subcommand handler. */
    switch(line[i]) {
        case 'C':
            /* Client Introduction: <id> C <remoteip> <remoteport> <localip> <localport> */
            if(id >= 0 && id < iauth_clients_size && line[++i]) iauth_cmd_C(id, &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid C line.");
            break;
        case 'D':
            /* Client Disconnect: <id> D */
            if(id >= 0 && id < iauth_clients_size) {
                if(iauth_clients[id].id == id) iauth_cmd_D(&iauth_clients[id]);
                else /* Ignore all other disconnects. */ ;
            }
            else iauth_flog(IAUTH_WARNING, "Received invalid D line.");
            break;
        case 'L':
            /* Login On Connect: <id> L <account>[:<accountstamp>][ <fakehost>] */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_L(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid L line.");
            break;
        case 'H':
            /* Hurry Up: <id> H <class> */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_H(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid H line.");
            break;
        case 'M':
            /* Server Name and Capacity: <id> M <servername> <capacity> */
            if(id == -1 && line[++i]) iauth_cmd_M(&line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid M line.");
            break;
        case 'N':
            /* Hostname Received: <id> N <hostname> */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_N(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid N line.");
            break;
        case 'd':
            /* Hostname Timeout: <id> d */
            if(id >= 0 && id < iauth_clients_size && iauth_clients[id].id == id) iauth_cmd_d(&iauth_clients[id]);
            else iauth_flog(IAUTH_WARNING, "Received invalid d line.");
            break;
        case 'P':
            /* Client Password: <id> P :<password ...> */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_P(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid P line.");
            break;
        case 'U':
            /* Client Username: <id> U <username> <hostname> <servername> :<userinfo ...> */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_U(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid U line.");
            break;
        case 'u':
            /* Client Username: <id> u <username> */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_u(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid u line.");
            break;
        case 'n':
            /* Client Nickname: <id> n <nickname> */
            if(id >= 0 && id < iauth_clients_size && line[++i] && iauth_clients[id].id == id) iauth_cmd_n(&iauth_clients[id], &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid n line.");
            break;
        case 'T':
            /* Client Registered: <id> T */
            if(id >= 0 && id < iauth_clients_size && iauth_clients[id].id == id) iauth_cmd_T(&iauth_clients[id]);
            else iauth_flog(IAUTH_WARNING, "Received invalid T line.");
            break;
        case 'E':
            /* Error: <id> E <type> :<additional text> */
            if(line[++i]) iauth_cmd_E(id, &line[++i]);
            else iauth_flog(IAUTH_WARNING, "Received invalid E line.");
            break;
        default:
            /* Invalid subcommand; ignore. */
            iauth_flog(IAUTH_WARNING, "Received invalid subcommand.");
            return;
    }

    /* Subcommand called, nothing to do; return and await next line. */
    return;
}

signed int main(signed int argc, char *argv[]) {
    char *line;

    signal(SIGPIPE, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    signal(SIGINT, iauth_signal);
    signal(SIGQUIT, iauth_signal);
    signal(SIGTERM, iauth_signal);

    if(argc > 1) iauth_logfile = argv[1];
    if(argc > 2) iauth_scriptfile = argv[2];
    if(argc > 3) iauth_debug = 1;

    iauth_flog(IAUTH_INFO, "Starting IAuth");

    iauth_query_version("mIRCxNet iauth"); //original from OGN
    iauth_query_policy("ARTU");
    iauth_stats_report();

    while(running && (line = iauth_read())) {
        iauth_parse(line);
    }

    iauth_flog(IAUTH_INFO, "Stopping IAuth");

    return EXIT_SUCCESS;
}
