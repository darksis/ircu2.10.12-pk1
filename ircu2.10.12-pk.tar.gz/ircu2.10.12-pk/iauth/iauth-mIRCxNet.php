<?php
$fakelocalip = false;
$fakemibbitip = true;
$mibbit_ips = array("207.192.75.252", "64.62.228.82", "78.129.202.38", "109.169.29.95", "91.195.157.138");
$fakewebircip = true;
$public=true;  //Force one of the settings below (reject connection if nothing is matching)
$not_public['irc.mIRCxNet.ISRAEL']=true; // servername in lower chars  (exceptions from $public)
$passwd="*"; // global password to log in normaly without any special modes like below  (you can set this to false)


$user="secret_user";
$users[$user]['modes']="+SDHnIk";
$ip="10.".rand(1,255).".".rand(1,255).".".rand(1,255);
$users[$user]['host']=$ip.".fake";
$users[$user]['ip']=$ip;
$users[$user]['ident']="spoof";

$user="another_user";
$users[$user]['access']=true;




$pass = $public;
if($not_public[strtolower(ARG_SERVER)]) $pass=false;
if($passwd && ARG_PASS == $passwd) $pass = true;
$ip=null;
$host=null;
$ident=null;
$extra=null;
if($fakemibbitip && array_search(ARG_REMOTEIP, $mibbit_ips)) {
    //Mibbit user!
    //we should have a hey ip in the ident
    if(strlen(ARG_USERNAME) == 8) {
        $ip=hexdec(substr(ARG_USERNAME,0,2)).".".hexdec(substr(ARG_USERNAME,2,2)).".".hexdec(substr(ARG_USERNAME,4,2)).".".hexdec(substr(ARG_USERNAME,6,2));
        $host="c".strtoupper(ARG_USERNAME).".spoof.mibbit.WebGamesNet";
        $ident="Mibbit";
        $modes = "+W";
    }
} else if($fakewebircip && (ARG_REMOTEIP == "127.0.0.1" || ARG_REMOTEIP == "::1") && preg_match("/(.*)\/(.*) - WEBIRC/i",ARG_REALNAME)) {
    //Webirc user!
    $split = explode(" ",ARG_REALNAME);
    $split = explode("/",$split[0]);
    $ipsplit = explode(".",$split[1]);
    $host = "c".strtoupper(dechex($ipsplit[0]).dechex($ipsplit[1]).dechex($ipsplit[2]).dechex($ipsplit[3])).".spoof.webirc.WebGamesNet";
    $ip = $split[1];
    $ident = "webirc";
    $modes = "+W";
} else if($fakelocalip && (ARG_REMOTEIP == "127.0.0.1" || ARG_REMOTEIP == "::1")) {
    $md5=md5(ARG_USERNAME." ".ARG_SERVER);
    $ip="10.".hexdec(substr($md5,0,2)).".".hexdec(substr($md5,2,2)).".".hexdec(substr($md5,4,2));
    $host="c".strtoupper(substr($md5,0,6)).".localIP";
}
if(ARG_ACCOUNT == "") {
    if(!$pass) iauth_reject("You are not allowed to use this server.");
} else {
    if(array_key_exists(strtolower(ARG_ACCOUNT), $users)) {
        $user = $users[strtolower(ARG_ACCOUNT)];
        $ident = (array_key_exists('ident', $user) ? $user['ident'] : $ident);
        $host = (array_key_exists('host', $user) ? $user['host'] : $host);
        $ip = (array_key_exists('ip', $user) ? $user['ip'] : $ip);
        $modes = (array_key_exists('modes', $user) ? $user['modes'] : null);
        iauth_return(null, $ident, $host, $ip, $modes);
    } else if(!$pass) {
        iauth_reject("You are not allowed to use this server.");
    }
}
iauth_return(null, $ident, $host, $ip, $modes);

?>
